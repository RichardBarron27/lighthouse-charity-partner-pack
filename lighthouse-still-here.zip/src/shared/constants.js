/**
 * Lighthouse by Red Specter — "Still Here"
 * Shared Constants
 */

const MSG_TYPES = {
  GET_SNOOZE_STATE: 'GET_SNOOZE_STATE',
  SET_SNOOZE: 'SET_SNOOZE',
  CLEAR_SNOOZE: 'CLEAR_SNOOZE',
  GET_STATUS: 'GET_STATUS'
};

const STORAGE_KEYS = {
  SNOOZE_UNTIL: 'snoozeUntil',
  VERSION: 'lighthouseVersion'
};

const PLATFORMS = {
  CHATGPT: 'chatgpt',
  CLAUDE: 'claude',
  GEMINI: 'gemini',
  COPILOT: 'copilot',
  PERPLEXITY: 'perplexity',
  CHARACTER_AI: 'character_ai',
  POE: 'poe',
  DEEPSEEK: 'deepseek',
  GROK: 'grok',
  PI: 'pi',
  LECHAT: 'lechat',
  HUGGINGCHAT: 'huggingchat'
};

const PLATFORM_NAMES = {
  chatgpt: 'ChatGPT',
  claude: 'Claude',
  gemini: 'Google Gemini',
  copilot: 'Microsoft Copilot',
  perplexity: 'Perplexity',
  character_ai: 'Character.ai',
  poe: 'Poe',
  deepseek: 'DeepSeek',
  grok: 'Grok',
  pi: 'Pi',
  lechat: 'Le Chat',
  huggingchat: 'HuggingChat'
};

const SENDER_ROLES = {
  USER: 'user',
  AI: 'ai'
};

const RISK_CATEGORIES = {
  self_harm_suicide: { name: 'Self-Harm & Suicide', color: '#ef4444' },
  eating_disorders: { name: 'Eating Disorders', color: '#f97316' },
  depression_despair: { name: 'Depression & Despair', color: '#7c3aed' },
  loneliness_isolation: { name: 'Loneliness & Isolation', color: '#6366f1' }
};

const AGE_GROUPS = {
  YOUTH: 'youth',
  OLDER_ADULT: 'older_adult',
  DEFAULT: 'default'
};

const TIMING = {
  ANALYZE_INTERVAL_MS: 2000,
  CONTENT_BUFFER_MAX_SIZE: 20,
  OBSERVER_THROTTLE_MS: 500,
  DEDUP_SET_MAX_SIZE: 2000,
  OVERLAY_COOLDOWN_MS: 300000,
  SNOOZE_DURATION_MS: 3600000,
  TRIGGER_THRESHOLD: 0.55
};

if (typeof window !== 'undefined') {
  window.Lighthouse = window.Lighthouse || {};
  Object.assign(window.Lighthouse, {
    MSG_TYPES, STORAGE_KEYS, PLATFORMS, PLATFORM_NAMES,
    SENDER_ROLES, RISK_CATEGORIES, AGE_GROUPS, TIMING
  });
}
