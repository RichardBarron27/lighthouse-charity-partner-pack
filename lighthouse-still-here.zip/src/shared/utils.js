/**
 * Lighthouse by Red Specter — "Still Here"
 * Shared Utilities
 */

const LighthouseUtils = {
  hash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return hash.toString(36);
  },

  fingerprint(sender, content, timestamp) {
    const truncated = (content || '').substring(0, 50);
    return this.hash(`${sender}|${truncated}|${timestamp || ''}`);
  },

  debounce(fn, delay) {
    let timer = null;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay);
    };
  },

  escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }
};

if (typeof window !== 'undefined') {
  window.Lighthouse = window.Lighthouse || {};
  window.Lighthouse.Utils = LighthouseUtils;
}
