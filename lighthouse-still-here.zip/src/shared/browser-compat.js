/**
 * Lighthouse by Red Specter — "Still Here"
 * Browser Compatibility Layer
 * Normalizes chrome.* vs browser.* API namespaces
 */

const browserAPI = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;

if (typeof window !== 'undefined') {
  window.Lighthouse = window.Lighthouse || {};
  window.Lighthouse.browserAPI = browserAPI;
}
