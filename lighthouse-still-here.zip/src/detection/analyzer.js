/**
 * Lighthouse by Red Specter — "Still Here"
 * Local Pattern Matching Analyzer
 *
 * All analysis happens in-memory. No messages are stored.
 * No network calls. No data leaves the browser.
 */

(function () {
  window.Lighthouse = window.Lighthouse || {};

  const CATEGORY_WEIGHTS = {
    self_harm_suicide: 1.6,
    eating_disorders: 1.3,
    depression_despair: 1.0,
    loneliness_isolation: 0.8
  };

  class Analyzer {
    constructor() {
      this.ageDetector = new window.Lighthouse.AgeContextDetector();
      this.lastTriggerTime = 0;
      this.fingerprints = new Set();
    }

    /**
     * Analyze a single message. Returns trigger data if threshold met, null otherwise.
     * @param {string} content - Message text
     * @param {string} sender - 'user' or 'ai'
     * @returns {object|null} - { category, score, helplines, ageGroup } or null
     */
    analyzeMessage(content, sender) {
      if (!content || content.length < 2) return null;

      const { TIMING, PATTERNS, getHelplines } = window.Lighthouse;

      // Check cooldown
      const now = Date.now();
      if (now - this.lastTriggerTime < TIMING.OVERLAY_COOLDOWN_MS) {
        return null;
      }

      // Check snooze (set by overlay/popup, stored in memory via service worker)
      if (this._isSnoozed()) return null;

      // Fingerprint dedup — don't re-analyze identical messages
      const fp = window.Lighthouse.Utils.hash(content.substring(0, 100));
      if (this.fingerprints.has(fp)) return null;
      this.fingerprints.add(fp);

      // Trim fingerprint set
      if (this.fingerprints.size > TIMING.DEDUP_SET_MAX_SIZE) {
        const entries = Array.from(this.fingerprints);
        this.fingerprints = new Set(entries.slice(Math.floor(entries.length / 2)));
      }

      // Update age context from user messages
      if (sender === 'user') {
        this.ageDetector.processMessage(content);
      }

      // Run pattern matching
      const matches = this._matchPatterns(content, sender);
      if (matches.length === 0) return null;

      // Score by category
      const categoryScores = this._scoreByCategoryCumulative(matches);
      const bestCategory = this._getBestCategory(categoryScores);

      if (!bestCategory) return null;

      // Calculate composite score
      const composite = this._compositeScore(categoryScores, bestCategory);

      if (composite < TIMING.TRIGGER_THRESHOLD) return null;

      // Trigger!
      this.lastTriggerTime = now;

      const ageGroup = this.ageDetector.getAgeGroup();
      const helplines = getHelplines(ageGroup, bestCategory.category);

      return {
        category: bestCategory.category,
        score: composite,
        helplines,
        ageGroup,
        categoryName: window.Lighthouse.RISK_CATEGORIES[bestCategory.category]?.name || bestCategory.category
      };
    }

    /**
     * Match all patterns against content.
     */
    _matchPatterns(content, sender) {
      const { PATTERNS } = window.Lighthouse;
      const matches = [];

      for (const pattern of PATTERNS) {
        // Check sender compatibility
        if (pattern.sender !== 'any' && pattern.sender !== sender) continue;

        if (pattern.regex.test(content)) {
          matches.push(pattern);
        }
      }

      return matches;
    }

    /**
     * Score each category using highest weight + diminishing boost.
     */
    _scoreByCategoryCumulative(matches) {
      const categoryMap = {};

      for (const match of matches) {
        if (!categoryMap[match.category]) {
          categoryMap[match.category] = [];
        }
        categoryMap[match.category].push(match.weight);
      }

      const scores = {};
      for (const [category, weights] of Object.entries(categoryMap)) {
        // Sort descending
        weights.sort((a, b) => b - a);

        // Highest weight is base score
        let score = weights[0];

        // Diminishing boost from additional matches: each adds 10% of remaining gap
        for (let i = 1; i < weights.length; i++) {
          const gap = 1.0 - score;
          score += gap * 0.10;
        }

        scores[category] = Math.min(score, 1.0);
      }

      return scores;
    }

    /**
     * Get best category after applying category weights.
     */
    _getBestCategory(categoryScores) {
      let best = null;
      let bestWeighted = 0;

      for (const [category, score] of Object.entries(categoryScores)) {
        const weight = CATEGORY_WEIGHTS[category] || 1.0;
        const weighted = score * weight;
        if (weighted > bestWeighted) {
          bestWeighted = weighted;
          best = { category, score, weighted };
        }
      }

      return best;
    }

    /**
     * Calculate composite score.
     * composite = (0.4 * max_category_score) + (0.6 * weighted_average)
     */
    _compositeScore(categoryScores, bestCategory) {
      const scores = Object.entries(categoryScores);
      if (scores.length === 0) return 0;

      // Weighted average
      let totalWeighted = 0;
      let totalWeight = 0;
      for (const [category, score] of scores) {
        const w = CATEGORY_WEIGHTS[category] || 1.0;
        totalWeighted += score * w;
        totalWeight += w;
      }
      const weightedAvg = totalWeight > 0 ? totalWeighted / totalWeight : 0;

      return (0.4 * bestCategory.score) + (0.6 * weightedAvg);
    }

    /**
     * Check if currently snoozed (via service worker state).
     */
    _isSnoozed() {
      // Snooze state is checked synchronously from a local variable
      // Updated via message from service worker
      return this._snoozedUntil && Date.now() < this._snoozedUntil;
    }

    setSnoozedUntil(timestamp) {
      this._snoozedUntil = timestamp;
    }

    reset() {
      this.ageDetector.reset();
      this.lastTriggerTime = 0;
      this.fingerprints.clear();
      this._snoozedUntil = 0;
    }
  }

  window.Lighthouse.Analyzer = Analyzer;
})();
