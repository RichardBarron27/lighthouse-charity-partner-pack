/**
 * Lighthouse by Red Specter — "Still Here"
 * UK Helplines & Age-Group Routing
 */

(function () {
  window.Lighthouse = window.Lighthouse || {};

  const HELPLINES = {
    samaritans: {
      name: 'Samaritans',
      number: '116 123',
      method: 'call',
      description: 'Free 24/7 listening service. Whatever you\'re going through, call any time.',
      url: 'https://www.samaritans.org',
      available: '24 hours, 365 days'
    },
    childline: {
      name: 'Childline',
      number: '0800 1111',
      method: 'call',
      description: 'Free, confidential support for young people under 19.',
      url: 'https://www.childline.org.uk',
      available: '24 hours'
    },
    youngminds: {
      name: 'YoungMinds',
      number: 'YM to 85258',
      method: 'text',
      description: 'Free text support for young people in crisis.',
      url: 'https://www.youngminds.org.uk',
      available: '24 hours'
    },
    silverline: {
      name: 'The Silver Line',
      number: '0800 4 70 80 90',
      method: 'call',
      description: 'Free, confidential helpline for older people.',
      url: 'https://www.thesilverline.org.uk',
      available: '24 hours'
    },
    ageuk: {
      name: 'Age UK',
      number: '0800 678 1602',
      method: 'call',
      description: 'Free advice and support for older people and their families.',
      url: 'https://www.ageuk.org.uk',
      available: '8am-7pm, 365 days'
    },
    mind: {
      name: 'Mind',
      number: '0300 123 3393',
      method: 'call',
      description: 'Information and support for mental health problems.',
      url: 'https://www.mind.org.uk',
      available: '9am-6pm, Mon-Fri'
    },
    beat: {
      name: 'Beat Eating Disorders',
      number: '0808 801 0677',
      method: 'call',
      description: 'Support for anyone affected by eating disorders.',
      url: 'https://www.beateatingdisorders.org.uk',
      available: '9am-8pm weekdays, 4pm-8pm weekends'
    }
  };

  /**
   * Get prioritized helplines based on age group and risk category.
   * Returns array of 3 helpline objects.
   */
  function getHelplines(ageGroup, category) {
    // Category override: eating disorders always show Beat first
    if (category === 'eating_disorders') {
      return [HELPLINES.beat, HELPLINES.samaritans, HELPLINES.mind];
    }

    // Age-group routing
    if (ageGroup === 'youth') {
      return [HELPLINES.childline, HELPLINES.youngminds, HELPLINES.samaritans];
    }

    if (ageGroup === 'older_adult') {
      return [HELPLINES.silverline, HELPLINES.ageuk, HELPLINES.samaritans];
    }

    // Default
    return [HELPLINES.samaritans, HELPLINES.mind, HELPLINES.beat];
  }

  window.Lighthouse.HELPLINES = HELPLINES;
  window.Lighthouse.getHelplines = getHelplines;
})();
