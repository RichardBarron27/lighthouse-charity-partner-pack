/**
 * Lighthouse by Red Specter — "Still Here"
 * Age Context Detection
 *
 * Uses cumulative scoring across conversation messages to infer
 * whether the user is likely a young person, older adult, or unknown.
 * No data stored — scores held in memory only.
 */

(function () {
  window.Lighthouse = window.Lighthouse || {};

  const YOUTH_PATTERNS = [
    /\b(school|homework|revision|classmate|class\s+mate)\b/i,
    /\b(mum|mom|dad|mummy|daddy|parents?)\b/i,
    /\b(teacher|head\s*teacher|form\s+tutor)\b/i,
    /\b(gcse|a[- ]?level|sats|btec|t[- ]?level)\b/i,
    /\b(year\s+(7|8|9|10|11|12|13)|sixth\s+form)\b/i,
    /\b(playground|break\s+time|lunch\s+time|assembly)\b/i,
    /\b(prom|school\s+trip|sports?\s+day)\b/i,
    /\b(pocket\s+money|allowance)\b/i,
    /\b(sleepover|play\s*date)\b/i,
    /\b(uni(versity)?\s+(application|offer|place|choice))\b/i,
    /\b(tiktok|snapchat|roblox|fortnite|minecraft)\b/i,
    /\b(bully|bullied|bullying)\s+(me|at\s+school)\b/i
  ];

  const OLDER_ADULT_PATTERNS = [
    /\b(retire[d]?|retirement|pension|state\s+pension)\b/i,
    /\b(grandchild|grandchildren|grandkids?|grandparent)\b/i,
    /\b(late\s+(wife|husband|partner|spouse)|widow|widower)\b/i,
    /\b(care\s+home|nursing\s+home|sheltered\s+housing|warden)\b/i,
    /\b(gp|doctor|hospital|consultant|specialist)\s+(said|told|appointment)\b/i,
    /\b(mobility|walking\s+(stick|frame)|wheelchair|stairlift)\b/i,
    /\b(war|national\s+service|worked\s+all\s+my\s+life)\b/i,
    /\b(meals?\s+on\s+wheels|day\s+centre|social\s+services)\b/i,
    /\b(arthritis|dementia|alzheimer|parkinson|stroke)\b/i,
    /\b(funeral|passed\s+away|lost\s+(my|him|her))\b/i,
    /\b(over\s+(60|65|70|75|80)|in\s+my\s+(60|70|80|90)s)\b/i,
    /\b(church|chapel|village|community\s+centre)\b/i
  ];

  class AgeContextDetector {
    constructor() {
      this.youthScore = 0;
      this.olderAdultScore = 0;
    }

    /**
     * Process a message and update age context scores.
     * Returns current age group assessment.
     */
    processMessage(text) {
      if (!text) return this.getAgeGroup();

      const lower = text.toLowerCase();

      for (const pattern of YOUTH_PATTERNS) {
        if (pattern.test(lower)) {
          this.youthScore += 1;
        }
      }

      for (const pattern of OLDER_ADULT_PATTERNS) {
        if (pattern.test(lower)) {
          this.olderAdultScore += 1;
        }
      }

      return this.getAgeGroup();
    }

    /**
     * Get current age group based on cumulative scores.
     * Requires at least 2 matches to classify (avoids false positives).
     */
    getAgeGroup() {
      const { AGE_GROUPS } = window.Lighthouse;

      if (this.youthScore >= 2 && this.youthScore > this.olderAdultScore) {
        return AGE_GROUPS.YOUTH;
      }

      if (this.olderAdultScore >= 2 && this.olderAdultScore > this.youthScore) {
        return AGE_GROUPS.OLDER_ADULT;
      }

      return AGE_GROUPS.DEFAULT;
    }

    reset() {
      this.youthScore = 0;
      this.olderAdultScore = 0;
    }
  }

  window.Lighthouse.AgeContextDetector = AgeContextDetector;
})();
