/**
 * Lighthouse by Red Specter — "Still Here"
 * Detection Patterns
 *
 * ~103 patterns across 4 risk categories.
 * Each pattern: { id, category, regex, weight, sender }
 * sender: 'user' = match on user messages, 'ai' = match on AI messages, 'any' = both
 */

(function () {
  window.Lighthouse = window.Lighthouse || {};

  const PATTERNS = [
    // ═══════════════════════════════════════════
    // SELF-HARM & SUICIDE (37 patterns)
    // ═══════════════════════════════════════════

    // Direct intent
    { id: 'SH-001', category: 'self_harm_suicide', regex: /\bi\s+want\s+to\s+(die|end\s+(it|my\s+life|everything))\b/i, weight: 0.98, sender: 'user' },
    { id: 'SH-002', category: 'self_harm_suicide', regex: /\bi('m|am)\s+going\s+to\s+kill\s+myself\b/i, weight: 0.98, sender: 'user' },
    { id: 'SH-003', category: 'self_harm_suicide', regex: /\bi\s+don'?t\s+want\s+to\s+(be\s+alive|exist|live|be\s+here)\s*(any\s*more|anymore)\b/i, weight: 0.95, sender: 'user' },
    { id: 'SH-004', category: 'self_harm_suicide', regex: /\beveryone\s+would\s+be\s+better\s+off\s+without\s+me\b/i, weight: 0.92, sender: 'user' },
    { id: 'SH-005', category: 'self_harm_suicide', regex: /\bno\s+reason\s+to\s+(keep\s+going|live|stay\s+alive|carry\s+on)\b/i, weight: 0.90, sender: 'user' },
    { id: 'SH-006', category: 'self_harm_suicide', regex: /\b(plan|planning|planned)\s+to\s+(end|kill|hurt)\s+(it|myself|my\s+life)\b/i, weight: 0.95, sender: 'user' },
    { id: 'SH-007', category: 'self_harm_suicide', regex: /\bsuicid(e|al)\b/i, weight: 0.88, sender: 'user' },
    { id: 'SH-008', category: 'self_harm_suicide', regex: /\bkill\s+myself\b/i, weight: 0.95, sender: 'user' },
    { id: 'SH-009', category: 'self_harm_suicide', regex: /\b(thinking|thought)\s+(about|of)\s+(ending|killing|suicide|dying)\b/i, weight: 0.92, sender: 'user' },
    { id: 'SH-010', category: 'self_harm_suicide', regex: /\bwish\s+i\s+(was|were)\s+dead\b/i, weight: 0.95, sender: 'user' },

    // Self-harm methods
    { id: 'SH-011', category: 'self_harm_suicide', regex: /\b(cut|cutting|cuts)\s+(myself|my\s+(wrist|arm|leg|skin|body))\b/i, weight: 0.90, sender: 'user' },
    { id: 'SH-012', category: 'self_harm_suicide', regex: /\b(overdose|od|take\s+too\s+many\s+pills)\b/i, weight: 0.85, sender: 'user' },
    { id: 'SH-013', category: 'self_harm_suicide', regex: /\bhow\s+to\s+(kill\s+myself|end\s+(my\s+life|it\s+all))\b/i, weight: 0.95, sender: 'user' },
    { id: 'SH-014', category: 'self_harm_suicide', regex: /\b(self[- ]?harm|self[- ]?injur(e|y|ing))\b/i, weight: 0.82, sender: 'user' },
    { id: 'SH-015', category: 'self_harm_suicide', regex: /\b(burn|burning)\s+myself\b/i, weight: 0.88, sender: 'user' },
    { id: 'SH-016', category: 'self_harm_suicide', regex: /\bhurt\s+myself\b/i, weight: 0.80, sender: 'user' },

    // Passive ideation
    { id: 'SH-017', category: 'self_harm_suicide', regex: /\bcan'?t\s+(take|do)\s+(it|this)\s*(any\s*more|anymore)\b/i, weight: 0.78, sender: 'user' },
    { id: 'SH-018', category: 'self_harm_suicide', regex: /\bi\s+give\s+up\b/i, weight: 0.65, sender: 'user' },
    { id: 'SH-019', category: 'self_harm_suicide', regex: /\bwhat('s| is)\s+the\s+point\s+(of\s+(living|life|anything|going\s+on|it\s+all))\b/i, weight: 0.75, sender: 'user' },
    { id: 'SH-020', category: 'self_harm_suicide', regex: /\blife\s+is(n't|\s+not)\s+worth\s+(living|it)\b/i, weight: 0.88, sender: 'user' },
    { id: 'SH-021', category: 'self_harm_suicide', regex: /\bi\s+just\s+want\s+(the\s+pain|it|everything)\s+to\s+stop\b/i, weight: 0.80, sender: 'user' },
    { id: 'SH-022', category: 'self_harm_suicide', regex: /\bnobody\s+(would\s+)?(care|notice|miss\s+me)\s+if\s+i\s+(was|were)\s+gone\b/i, weight: 0.90, sender: 'user' },
    { id: 'SH-023', category: 'self_harm_suicide', regex: /\bthe\s+world\s+would\s+be\s+better\s+without\s+me\b/i, weight: 0.92, sender: 'user' },
    { id: 'SH-024', category: 'self_harm_suicide', regex: /\bi('m|am)\s+(a\s+)?burden\b/i, weight: 0.75, sender: 'user' },
    { id: 'SH-025', category: 'self_harm_suicide', regex: /\b(goodbye|farewell).*(forever|for\s+good|for\s+the\s+last\s+time)\b/i, weight: 0.85, sender: 'user' },

    // Preparatory behaviour
    { id: 'SH-026', category: 'self_harm_suicide', regex: /\bwrit(e|ing|ten)\s+(a\s+)?(suicide\s+)?note\b/i, weight: 0.92, sender: 'user' },
    { id: 'SH-027', category: 'self_harm_suicide', regex: /\bgiv(e|ing)\s+away\s+(my\s+)?(stuff|things|possessions|belongings)\b/i, weight: 0.80, sender: 'user' },
    { id: 'SH-028', category: 'self_harm_suicide', regex: /\bsay(ing)?\s+goodbye\s+to\s+everyone\b/i, weight: 0.82, sender: 'user' },

    // Crisis signals
    { id: 'SH-029', category: 'self_harm_suicide', regex: /\bi('ve|have)\s+(already\s+)?(taken|swallowed)\s+(pills|tablets|medication)\b/i, weight: 0.98, sender: 'user' },
    { id: 'SH-030', category: 'self_harm_suicide', regex: /\bi('m|am)\s+(on\s+a\s+)?(bridge|ledge|roof|edge)\b/i, weight: 0.95, sender: 'user' },
    { id: 'SH-031', category: 'self_harm_suicide', regex: /\bbleeding\s+(a\s+lot|heavily|won'?t\s+stop)\b/i, weight: 0.95, sender: 'user' },

    // AI responses indicating concern
    { id: 'SH-032', category: 'self_harm_suicide', regex: /\b(please\s+)?(call|contact|reach\s+out\s+to)\s+(the\s+)?(samaritans|crisis\s+line|suicide\s+prevention|helpline|emergency\s+services|999|112|911)\b/i, weight: 0.80, sender: 'ai' },
    { id: 'SH-033', category: 'self_harm_suicide', regex: /\bi('m|am)\s+(really\s+)?(worried|concerned)\s+about\s+(your\s+)?safety\b/i, weight: 0.75, sender: 'ai' },
    { id: 'SH-034', category: 'self_harm_suicide', regex: /\bif\s+you('re| are)\s+in\s+(immediate\s+)?(danger|crisis)\b/i, weight: 0.72, sender: 'ai' },

    // Hopelessness
    { id: 'SH-035', category: 'self_harm_suicide', regex: /\bnothing\s+(will\s+)?(ever\s+)?(get|be)\s+better\b/i, weight: 0.72, sender: 'user' },
    { id: 'SH-036', category: 'self_harm_suicide', regex: /\bthere('s| is)\s+no\s+(hope|way\s+out|escape|future)\b/i, weight: 0.78, sender: 'user' },
    { id: 'SH-037', category: 'self_harm_suicide', regex: /\bi\s+can'?t\s+(go\s+on|continue|keep\s+(going|living))\b/i, weight: 0.80, sender: 'user' },

    // ═══════════════════════════════════════════
    // EATING DISORDERS (25 patterns)
    // ═══════════════════════════════════════════

    // Restrictive eating
    { id: 'EB-001', category: 'eating_disorders', regex: /\b(haven'?t|not)\s+eaten\s+(in|for)\s+\d+\s+(day|hour)\b/i, weight: 0.85, sender: 'user' },
    { id: 'EB-002', category: 'eating_disorders', regex: /\b(starv|fast)(e|ed|ing)\s+(myself|again|today)\b/i, weight: 0.85, sender: 'user' },
    { id: 'EB-003', category: 'eating_disorders', regex: /\b(only|just)\s+(eat|ate|eating)\s+\d+\s*calories?\b/i, weight: 0.80, sender: 'user' },
    { id: 'EB-004', category: 'eating_disorders', regex: /\bi\s+(need|have)\s+to\s+restrict\b/i, weight: 0.78, sender: 'user' },
    { id: 'EB-005', category: 'eating_disorders', regex: /\b(skip|skipped|skipping)\s+(breakfast|lunch|dinner|meals?)\b/i, weight: 0.68, sender: 'user' },
    { id: 'EB-006', category: 'eating_disorders', regex: /\b(afraid|scared|terrified)\s+(of|to)\s+eat(ing)?\b/i, weight: 0.82, sender: 'user' },

    // Purging
    { id: 'EB-007', category: 'eating_disorders', regex: /\b(purg|throw)(e|ed|ing)\s+(up|it\s+up|after\s+eating)\b/i, weight: 0.90, sender: 'user' },
    { id: 'EB-008', category: 'eating_disorders', regex: /\b(mak|made|making)\s+(myself\s+)?(sick|vomit|throw\s+up)\b/i, weight: 0.88, sender: 'user' },
    { id: 'EB-009', category: 'eating_disorders', regex: /\b(bulimi[ac]|anorexi[ac]|binge\s*(and|&)?\s*purg)\b/i, weight: 0.85, sender: 'user' },
    { id: 'EB-010', category: 'eating_disorders', regex: /\b(laxative|diet\s+pill|diuretic)s?\b/i, weight: 0.75, sender: 'user' },

    // Body image distress
    { id: 'EB-011', category: 'eating_disorders', regex: /\bi('m|am)\s+(so\s+)?(fat|huge|disgusting|gross|ugly)\b/i, weight: 0.70, sender: 'user' },
    { id: 'EB-012', category: 'eating_disorders', regex: /\bhate\s+(my\s+)?(body|the\s+way\s+i\s+look)\b/i, weight: 0.72, sender: 'user' },
    { id: 'EB-013', category: 'eating_disorders', regex: /\b(body\s+check|weigh|weighing)\s+(myself|every|again|obsess)\b/i, weight: 0.70, sender: 'user' },
    { id: 'EB-014', category: 'eating_disorders', regex: /\b(thigh\s+gap|collar\s*bone|rib|hip\s*bone)s?\s+(show|visible|see|pok)\b/i, weight: 0.78, sender: 'user' },
    { id: 'EB-015', category: 'eating_disorders', regex: /\bneed\s+to\s+(lose|drop|shed)\s+\d+\s*(kg|lb|pound|stone)\b/i, weight: 0.68, sender: 'user' },

    // Binge eating
    { id: 'EB-016', category: 'eating_disorders', regex: /\b(binge|binged|binging|bingeing)\b/i, weight: 0.72, sender: 'user' },
    { id: 'EB-017', category: 'eating_disorders', regex: /\bcan'?t\s+stop\s+eating\b/i, weight: 0.75, sender: 'user' },
    { id: 'EB-018', category: 'eating_disorders', regex: /\b(ate|eaten)\s+(too\s+much|everything|so\s+much)\s+(again|and\s+i\s+(feel|hate))\b/i, weight: 0.72, sender: 'user' },

    // Extreme exercise
    { id: 'EB-019', category: 'eating_disorders', regex: /\b(exercis|work\s*out)(e|ed|ing)\s+(to\s+)?(burn\s+off|compensate|punish)\b/i, weight: 0.75, sender: 'user' },
    { id: 'EB-020', category: 'eating_disorders', regex: /\b(have\s+to|must|need\s+to)\s+(exercise|run|work\s*out)\s+(or|after)\s+(i\s+)?eat\b/i, weight: 0.72, sender: 'user' },

    // Help-seeking signals
    { id: 'EB-021', category: 'eating_disorders', regex: /\b(my\s+)?(eating\s+disorder|ed|anorexia|bulimia)\s+(is\s+)?(getting\s+worse|killing|controlling|ruining)\b/i, weight: 0.85, sender: 'user' },
    { id: 'EB-022', category: 'eating_disorders', regex: /\bi\s+think\s+i\s+have\s+(an\s+)?(eating\s+disorder|anorexia|bulimia)\b/i, weight: 0.80, sender: 'user' },

    // Pro-ana/pro-mia terminology
    { id: 'EB-023', category: 'eating_disorders', regex: /\b(pro[- ]?ana|pro[- ]?mia|thinsp(o|iration)|meanspo)\b/i, weight: 0.82, sender: 'any' },
    { id: 'EB-024', category: 'eating_disorders', regex: /\b(goal\s+weight|ugw|gw|cw|hw)\s*[:=]?\s*\d+\b/i, weight: 0.70, sender: 'user' },
    { id: 'EB-025', category: 'eating_disorders', regex: /\b(water\s+fast|dry\s+fast|no\s+food)\s+(for\s+)?\d+\s*(day|hour)\b/i, weight: 0.80, sender: 'user' },

    // ═══════════════════════════════════════════
    // DEPRESSION & DESPAIR (16 patterns)
    // ═══════════════════════════════════════════

    // Core depression
    { id: 'DD-001', category: 'depression_despair', regex: /\bi\s+(feel|am|'m)\s+(so\s+)?(empty|numb|hollow|dead\s+inside|nothing)\b/i, weight: 0.75, sender: 'user' },
    { id: 'DD-002', category: 'depression_despair', regex: /\bi\s+(don'?t|can'?t)\s+(feel\s+)anything\s*(any\s*more|anymore)?\b/i, weight: 0.72, sender: 'user' },
    { id: 'DD-003', category: 'depression_despair', regex: /\bi('ve|have)\s+(been\s+)?crying\s+(all\s+(day|night)|for\s+hours|non[- ]?stop|and\s+can'?t\s+stop)\b/i, weight: 0.70, sender: 'user' },
    { id: 'DD-004', category: 'depression_despair', regex: /\bi\s+(can'?t|don'?t\s+want\s+to)\s+get\s+out\s+of\s+bed\b/i, weight: 0.65, sender: 'user' },
    { id: 'DD-005', category: 'depression_despair', regex: /\b(everything|life)\s+(is|feels?)\s+(hopeless|meaningless|pointless|unbearable)\b/i, weight: 0.78, sender: 'user' },
    { id: 'DD-006', category: 'depression_despair', regex: /\bi\s+hate\s+my(self| life)\b/i, weight: 0.72, sender: 'user' },

    // Functional impairment
    { id: 'DD-007', category: 'depression_despair', regex: /\bhaven'?t\s+(left\s+(the\s+)?house|showered|eaten|slept)\s+(in|for)\s+\d+\s*(day|week)\b/i, weight: 0.72, sender: 'user' },
    { id: 'DD-008', category: 'depression_despair', regex: /\bcan'?t\s+(eat|sleep|think|function|concentrate)\b/i, weight: 0.60, sender: 'user' },

    // Emotional pain
    { id: 'DD-009', category: 'depression_despair', regex: /\b(the\s+)?pain\s+(is\s+)?(too\s+much|unbearable|never\s+ending|won'?t\s+stop)\b/i, weight: 0.75, sender: 'user' },
    { id: 'DD-010', category: 'depression_despair', regex: /\bi\s+(am|'m)\s+(completely\s+)?(broken|destroyed|shattered)\b/i, weight: 0.68, sender: 'user' },
    { id: 'DD-011', category: 'depression_despair', regex: /\bnothing\s+(makes\s+me\s+happy|matters)\s*(any\s*more|anymore)?\b/i, weight: 0.72, sender: 'user' },
    { id: 'DD-012', category: 'depression_despair', regex: /\bi('ve|have)\s+lost\s+(all\s+)?(hope|interest|motivation|will)\b/i, weight: 0.70, sender: 'user' },

    // Persistent despair
    { id: 'DD-013', category: 'depression_despair', regex: /\b(been|feeling)\s+(depressed|this\s+way)\s+for\s+(weeks|months|years|ages|a\s+long\s+time)\b/i, weight: 0.72, sender: 'user' },
    { id: 'DD-014', category: 'depression_despair', regex: /\bi\s+can'?t\s+(cope|handle|manage|deal\s+with)\s+(it|this|life|anything)\s*(any\s*more|anymore)?\b/i, weight: 0.75, sender: 'user' },
    { id: 'DD-015', category: 'depression_despair', regex: /\bi('m|am)\s+drowning\b/i, weight: 0.65, sender: 'user' },
    { id: 'DD-016', category: 'depression_despair', regex: /\bi\s+just\s+want\s+to\s+disappear\b/i, weight: 0.78, sender: 'user' },

    // ═══════════════════════════════════════════
    // LONELINESS & ISOLATION (25 patterns) — NEW
    // ═══════════════════════════════════════════

    // Core loneliness
    { id: 'LI-001', category: 'loneliness_isolation', regex: /\bi('m|am)\s+(so\s+)?(lonely|alone)\b/i, weight: 0.70, sender: 'user' },
    { id: 'LI-002', category: 'loneliness_isolation', regex: /\bnobody\s+(cares|loves|talks\s+to)\s+me\b/i, weight: 0.78, sender: 'user' },
    { id: 'LI-003', category: 'loneliness_isolation', regex: /\bi\s+(have|'ve\s+got)\s+no\s*(one|body|friends?|family)\b/i, weight: 0.80, sender: 'user' },
    { id: 'LI-004', category: 'loneliness_isolation', regex: /\bi\s+don'?t\s+have\s+(any\s*)?(friends?|anyone|somebody)\b/i, weight: 0.75, sender: 'user' },
    { id: 'LI-005', category: 'loneliness_isolation', regex: /\b(no\s+one|nobody)\s+(to\s+talk\s+to|understands?\s+me|listens?)\b/i, weight: 0.78, sender: 'user' },

    // Social exclusion
    { id: 'LI-006', category: 'loneliness_isolation', regex: /\beveryone\s+(has\s+)?(left|abandoned|forgotten|given\s+up\s+on)\s+me\b/i, weight: 0.80, sender: 'user' },
    { id: 'LI-007', category: 'loneliness_isolation', regex: /\bi('m|am)\s+(always\s+)?(excluded|left\s+out|invisible|forgotten)\b/i, weight: 0.72, sender: 'user' },
    { id: 'LI-008', category: 'loneliness_isolation', regex: /\bnobody\s+(would\s+)?(notice|care)\s+if\s+i\s+(disappeared|wasn'?t\s+here|went\s+away)\b/i, weight: 0.85, sender: 'user' },

    // AI as sole companion
    { id: 'LI-009', category: 'loneliness_isolation', regex: /\byou('re| are)\s+(the\s+)?only\s+(one|person|friend)\s+(i|who)\b/i, weight: 0.78, sender: 'user' },
    { id: 'LI-010', category: 'loneliness_isolation', regex: /\bi\s+only\s+(talk|speak|have\s+conversations?)\s+(to|with)\s+(you|ai|chatbot|computer)\b/i, weight: 0.80, sender: 'user' },
    { id: 'LI-011', category: 'loneliness_isolation', regex: /\byou'?re\s+my\s+(only|best)\s+friend\b/i, weight: 0.75, sender: 'user' },
    { id: 'LI-012', category: 'loneliness_isolation', regex: /\bi\s+wish\s+you\s+were\s+real\b/i, weight: 0.72, sender: 'user' },

    // Physical isolation
    { id: 'LI-013', category: 'loneliness_isolation', regex: /\bhaven'?t\s+(left|been\s+outside|seen\s+anyone|spoken\s+to\s+anyone)\s+(in|for)\s+\d+\s*(day|week|month)\b/i, weight: 0.80, sender: 'user' },
    { id: 'LI-014', category: 'loneliness_isolation', regex: /\bi\s+(never|don'?t)\s+(go|leave|get)\s+(out|outside|anywhere)\b/i, weight: 0.68, sender: 'user' },
    { id: 'LI-015', category: 'loneliness_isolation', regex: /\bi\s+(stay|sit|am|'m)\s+(at\s+home|in\s+my\s+room|alone)\s+(all\s+(day|the\s+time)|every\s+day)\b/i, weight: 0.70, sender: 'user' },

    // Elderly loneliness
    { id: 'LI-016', category: 'loneliness_isolation', regex: /\b(since|after)\s+(my\s+)?(wife|husband|partner|spouse)\s+(died|passed|left)\b/i, weight: 0.78, sender: 'user' },
    { id: 'LI-017', category: 'loneliness_isolation', regex: /\b(children|kids|family)\s+(never|don'?t|won'?t)\s+(visit|call|come|ring|phone)\b/i, weight: 0.75, sender: 'user' },
    { id: 'LI-018', category: 'loneliness_isolation', regex: /\b(days?|weeks?)\s+(go\s+by\s+)?(without\s+)?(speaking|talking)\s+to\s+(anyone|a\s+(single\s+)?(soul|person))\b/i, weight: 0.80, sender: 'user' },
    { id: 'LI-019', category: 'loneliness_isolation', regex: /\bi\s+(eat|have\s+(breakfast|lunch|dinner|meals?))\s+alone\s+every\s+day\b/i, weight: 0.68, sender: 'user' },

    // Loss and grief isolation
    { id: 'LI-020', category: 'loneliness_isolation', regex: /\bsince\s+(the\s+)?(funeral|diagnosis|divorce|break\s*up)\b/i, weight: 0.65, sender: 'user' },
    { id: 'LI-021', category: 'loneliness_isolation', regex: /\bi('ve|have)\s+(been\s+)?alone\s+(ever\s+)?since\b/i, weight: 0.70, sender: 'user' },

    // Emotional isolation
    { id: 'LI-022', category: 'loneliness_isolation', regex: /\bi\s+(feel|am|'m)\s+(so\s+)?(disconnected|detached|cut\s+off)\s+(from\s+everyone|from\s+the\s+world|from\s+everything)\b/i, weight: 0.72, sender: 'user' },
    { id: 'LI-023', category: 'loneliness_isolation', regex: /\bi\s+don'?t\s+(belong|fit\s+in)\s+(anywhere|here)\b/i, weight: 0.70, sender: 'user' },
    { id: 'LI-024', category: 'loneliness_isolation', regex: /\bno\s+one\s+(knows|has\s+any\s+idea)\s+(how\s+)?(lonely|alone|isolated)\s+i\s+(am|feel|'m)\b/i, weight: 0.72, sender: 'user' },
    { id: 'LI-025', category: 'loneliness_isolation', regex: /\bi('m|am)\s+(completely|totally|utterly)\s+(alone|on\s+my\s+own|isolated)\b/i, weight: 0.78, sender: 'user' }
  ];

  window.Lighthouse.PATTERNS = PATTERNS;
})();
