/**
 * Lighthouse by Red Specter — "Still Here"
 * Observer Manager
 * Throttled MutationObserver wrapper.
 */

(function () {
  window.Lighthouse = window.Lighthouse || {};

  class ObserverManager {
    constructor(extractor) {
      this.extractor = extractor;
      this.observer = null;
      this.pendingMutations = [];
      this.flushScheduled = false;
      this.throttleMs = window.Lighthouse.TIMING
        ? window.Lighthouse.TIMING.OBSERVER_THROTTLE_MS : 500;
    }

    observe(targetNode) {
      this.disconnect();
      this.observer = new MutationObserver((mutations) => {
        this.pendingMutations.push(...mutations);
        if (!this.flushScheduled) {
          this.flushScheduled = true;
          setTimeout(() => this.processMutations(), this.throttleMs);
        }
      });
      this.observer.observe(targetNode, { childList: true, subtree: true });
    }

    processMutations() {
      const mutations = this.pendingMutations.splice(0);
      this.flushScheduled = false;

      for (const mutation of mutations) {
        for (const addedNode of mutation.addedNodes) {
          if (addedNode.nodeType !== Node.ELEMENT_NODE) continue;
          try {
            const messages = this.extractor.extractMessagesFromNode(addedNode);
            for (const msg of messages) {
              if (!msg || !msg.content) continue;
              const fp = this.extractor.getMessageFingerprint(msg);
              if (!this.extractor.observedMessages.has(fp)) {
                this.extractor.observedMessages.add(fp);
                this.extractor.messageBuffer.push(msg);
                if (this.extractor.observedMessages.size > this.extractor.dedupMaxSize) {
                  const entries = Array.from(this.extractor.observedMessages);
                  const half = Math.floor(entries.length / 2);
                  this.extractor.observedMessages = new Set(entries.slice(half));
                }
              }
            }
          } catch (err) {
            // Silent — don't disrupt the page
          }
        }
      }

      const maxSize = window.Lighthouse.TIMING
        ? window.Lighthouse.TIMING.CONTENT_BUFFER_MAX_SIZE : 20;
      if (this.extractor.messageBuffer.length >= maxSize) {
        this.extractor.analyzeBuffer();
      }
    }

    disconnect() {
      if (this.observer) {
        this.observer.disconnect();
        this.observer = null;
      }
      this.pendingMutations = [];
      this.flushScheduled = false;
    }
  }

  window.Lighthouse.ObserverManager = ObserverManager;
})();
