/**
 * Lighthouse by Red Specter — "Still Here"
 * Shadow DOM Overlay
 *
 * Displays helpline information when a crisis pattern is detected.
 * Uses Shadow DOM for complete CSS isolation from the host page.
 */

(function () {
  window.Lighthouse = window.Lighthouse || {};

  const LIGHTHOUSE_SVG = `<svg viewBox="0 0 64 64" width="32" height="32" xmlns="http://www.w3.org/2000/svg">
    <circle cx="32" cy="32" r="30" fill="#1a1a2e" stroke="#f4a261" stroke-width="2"/>
    <rect x="27" y="14" width="10" height="30" rx="2" fill="#f4a261"/>
    <rect x="24" y="44" width="16" height="6" rx="1" fill="#f4a261"/>
    <polygon points="32,8 26,14 38,14" fill="#f4a261"/>
    <circle cx="32" cy="22" r="3" fill="#fff" opacity="0.9"/>
    <line x1="32" y1="22" x2="18" y2="16" stroke="#fff" stroke-width="1.5" opacity="0.6" stroke-linecap="round"/>
    <line x1="32" y1="22" x2="46" y2="16" stroke="#fff" stroke-width="1.5" opacity="0.6" stroke-linecap="round"/>
    <line x1="32" y1="22" x2="16" y2="22" stroke="#fff" stroke-width="1.5" opacity="0.6" stroke-linecap="round"/>
    <line x1="32" y1="22" x2="48" y2="22" stroke="#fff" stroke-width="1.5" opacity="0.6" stroke-linecap="round"/>
  </svg>`;

  class Overlay {
    constructor() {
      this.host = null;
      this.shadowRoot = null;
      this.visible = false;
      this.dismissCallback = null;
    }

    show(triggerData) {
      if (this.visible) return;
      this._create(triggerData);
      this.visible = true;
    }

    hide() {
      if (!this.visible || !this.host) return;
      const container = this.shadowRoot.querySelector('.lighthouse-container');
      if (container) {
        container.style.transform = 'translateX(120%)';
        container.style.opacity = '0';
        setTimeout(() => this._remove(), 400);
      } else {
        this._remove();
      }
      this.visible = false;
    }

    snooze() {
      const { browserAPI, MSG_TYPES } = window.Lighthouse;
      browserAPI.runtime.sendMessage({ type: MSG_TYPES.SET_SNOOZE });
      this.hide();
    }

    _create(triggerData) {
      // Remove any existing overlay
      this._remove();

      this.host = document.createElement('div');
      this.host.id = 'lighthouse-still-here';
      this.host.style.cssText = 'all: initial; position: fixed; z-index: 2147483647; bottom: 20px; right: 20px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;';

      this.shadowRoot = this.host.attachShadow({ mode: 'closed' });

      const helplines = triggerData.helplines || [];

      const helplineCards = helplines.map(h => `
        <div class="helpline-card">
          <div class="helpline-icon">${h.method === 'text' ? '&#x1F4AC;' : '&#x1F4DE;'}</div>
          <div class="helpline-info">
            <div class="helpline-name">${h.name}</div>
            <div class="helpline-number">${h.method === 'text' ? 'Text ' : 'Call '}<strong>${h.number}</strong></div>
            <div class="helpline-desc">${h.description}</div>
          </div>
        </div>
      `).join('');

      this.shadowRoot.innerHTML = `
        <style>
          * { box-sizing: border-box; margin: 0; padding: 0; }

          .lighthouse-container {
            width: 360px;
            max-height: 90vh;
            overflow-y: auto;
            background: #1a1a2e;
            border: 1px solid #f4a261;
            border-radius: 16px;
            padding: 24px;
            color: #f0f0f0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            font-size: 14px;
            line-height: 1.5;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            transform: translateX(120%);
            opacity: 0;
            transition: transform 0.5s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.4s ease;
          }

          .lighthouse-container.visible {
            transform: translateX(0);
            opacity: 1;
          }

          .header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
          }

          .header-icon {
            flex-shrink: 0;
            display: flex;
            align-items: center;
          }

          .header-text h2 {
            font-size: 18px;
            font-weight: 600;
            color: #f4a261;
            margin: 0;
          }

          .header-text p {
            font-size: 13px;
            color: #c0c0c0;
            margin: 4px 0 0 0;
          }

          .close-btn {
            position: absolute;
            top: 12px;
            right: 12px;
            background: none;
            border: none;
            color: #888;
            font-size: 20px;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: 4px;
            line-height: 1;
          }
          .close-btn:hover { color: #f0f0f0; background: rgba(255,255,255,0.1); }

          .message {
            font-size: 15px;
            color: #e0e0e0;
            margin-bottom: 20px;
            line-height: 1.6;
          }

          .helpline-card {
            display: flex;
            gap: 12px;
            padding: 14px;
            background: rgba(255, 255, 255, 0.06);
            border-radius: 10px;
            margin-bottom: 10px;
            border: 1px solid rgba(244, 162, 97, 0.15);
            transition: background 0.2s;
          }
          .helpline-card:hover {
            background: rgba(255, 255, 255, 0.1);
          }

          .helpline-icon {
            font-size: 24px;
            flex-shrink: 0;
            margin-top: 2px;
          }

          .helpline-info {
            flex: 1;
          }

          .helpline-name {
            font-weight: 600;
            color: #f4a261;
            font-size: 14px;
          }

          .helpline-number {
            font-size: 15px;
            color: #fff;
            margin: 2px 0;
          }
          .helpline-number strong {
            font-size: 16px;
            letter-spacing: 0.5px;
          }

          .helpline-desc {
            font-size: 12px;
            color: #999;
            margin-top: 2px;
          }

          .actions {
            display: flex;
            gap: 10px;
            margin-top: 18px;
          }

          .btn {
            flex: 1;
            padding: 10px 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            transition: background 0.2s, transform 0.1s;
          }
          .btn:active { transform: scale(0.97); }

          .btn-dismiss {
            background: rgba(255, 255, 255, 0.08);
            color: #ccc;
          }
          .btn-dismiss:hover { background: rgba(255, 255, 255, 0.14); }

          .btn-snooze {
            background: rgba(244, 162, 97, 0.15);
            color: #f4a261;
          }
          .btn-snooze:hover { background: rgba(244, 162, 97, 0.25); }

          .footer {
            text-align: center;
            margin-top: 16px;
            font-size: 11px;
            color: #555;
          }

          .footer-line {
            margin-bottom: 6px;
          }

          .emergency-notice {
            color: #e57373;
            font-weight: 500;
            font-size: 11px;
            margin-top: 6px;
          }

          .footer-brand {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            margin-top: 8px;
            opacity: 0.5;
          }

          .footer-brand:hover {
            opacity: 0.7;
          }

          .rs-logo {
            display: inline-flex;
          }
        </style>

        <div class="lighthouse-container" role="dialog" aria-label="Crisis support helplines">
          <button class="close-btn" aria-label="Dismiss" title="Dismiss">&times;</button>

          <div class="header">
            <div class="header-icon">${LIGHTHOUSE_SVG}</div>
            <div class="header-text">
              <h2>Still Here</h2>
              <p>by Lighthouse</p>
            </div>
          </div>

          <div class="message">
            You're not alone. Real people are ready to listen, right now.
          </div>

          ${helplineCards}

          <div class="actions">
            <button class="btn btn-dismiss">Dismiss</button>
            <button class="btn btn-snooze">Remind me later</button>
          </div>

          <div class="footer">
            <div class="footer-line">Lighthouse by Red Specter Security Research</div>
            <div class="footer-line">100% local. No data ever leaves your browser.</div>
            <div class="emergency-notice">Not a substitute for emergency services. If in immediate danger call 999 or 112.</div>
            <div class="footer-brand">
              <span class="rs-logo"><svg viewBox="0 0 20 20" width="14" height="14" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="9" fill="none" stroke="#c0392b" stroke-width="1.5"/><text x="10" y="14" text-anchor="middle" font-size="11" font-weight="bold" fill="#c0392b" font-family="Arial,sans-serif">R</text></svg></span>
              <span style="font-size:10px; color:#666;">Red Specter</span>
            </div>
          </div>
        </div>
      `;

      document.body.appendChild(this.host);

      // Bind events
      const container = this.shadowRoot.querySelector('.lighthouse-container');
      const closeBtn = this.shadowRoot.querySelector('.close-btn');
      const dismissBtn = this.shadowRoot.querySelector('.btn-dismiss');
      const snoozeBtn = this.shadowRoot.querySelector('.btn-snooze');

      closeBtn.addEventListener('click', () => this.hide());
      dismissBtn.addEventListener('click', () => this.hide());
      snoozeBtn.addEventListener('click', () => this.snooze());

      // Slide in after a frame
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          container.classList.add('visible');
        });
      });
    }

    _remove() {
      if (this.host && this.host.parentNode) {
        this.host.parentNode.removeChild(this.host);
      }
      this.host = null;
      this.shadowRoot = null;
    }
  }

  window.Lighthouse.Overlay = Overlay;
})();
