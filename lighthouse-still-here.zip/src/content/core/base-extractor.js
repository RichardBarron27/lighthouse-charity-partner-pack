/**
 * Lighthouse by Red Specter — "Still Here"
 * Base Extractor
 *
 * Abstract base class for chatbot platform extractors.
 * Messages have sender role 'user' or 'ai'.
 * Messages are analyzed locally and discarded — never stored.
 */

(function () {
  window.Lighthouse = window.Lighthouse || {};

  const { SelectorEngine, ObserverManager, Analyzer, Overlay, Utils, TIMING, SENDER_ROLES } = window.Lighthouse;

  class BaseExtractor {
    constructor(platformKey) {
      this.platformKey = platformKey;
      this.selectors = null;
      this.observedMessages = new Set();
      this.messageBuffer = [];
      this.observerManager = null;
      this.analyzeInterval = null;
      this.containerCheckInterval = null;
      this.enabled = false;
      this.dedupMaxSize = TIMING ? TIMING.DEDUP_SET_MAX_SIZE : 2000;
      this.analyzeIntervalMs = TIMING ? TIMING.ANALYZE_INTERVAL_MS : 2000;

      // Local analysis — no API, no server
      this.analyzer = new Analyzer();
      this.overlay = new Overlay();
    }

    async init() {
      console.log(`[Lighthouse] Initializing ${this.platformKey} extractor`);

      // Check snooze state from service worker
      this._loadSnoozeState();

      this.enabled = true;
      this.selectors = this.getSelectors();
      this.analyzeInterval = setInterval(() => this.analyzeBuffer(), this.analyzeIntervalMs);
      await this.waitAndObserve();
      this.containerCheckInterval = setInterval(() => this.checkContainer(), 5000);
    }

    async waitAndObserve() {
      const container = await SelectorEngine.waitFor(
        this.selectors.messageContainer, 15000, document
      );

      if (container) {
        console.log(`[Lighthouse] ${this.platformKey}: Message container found`);
        this.observerManager = new ObserverManager(this);
        this.observerManager.observe(container);
        this.currentContainer = container;
        this.extractExistingMessages(container);
      } else {
        console.warn(`[Lighthouse] ${this.platformKey}: Message container not found`);
      }
    }

    async checkContainer() {
      if (!this.enabled) return;
      if (this.currentContainer && !document.contains(this.currentContainer)) {
        console.log(`[Lighthouse] ${this.platformKey}: Container detached, re-attaching`);
        if (this.observerManager) this.observerManager.disconnect();
        await this.waitAndObserve();
      }
    }

    extractExistingMessages(container) {
      const messageNodes = SelectorEngine.queryAll(container, this.selectors.messageRow);
      for (const node of messageNodes) {
        try {
          const messages = this.extractMessagesFromNode(node);
          for (const msg of messages) {
            if (!msg || !msg.content) continue;
            const fp = this.getMessageFingerprint(msg);
            if (!this.observedMessages.has(fp)) {
              if (this.observedMessages.size >= this.dedupMaxSize) {
                const entries = Array.from(this.observedMessages);
                this.observedMessages = new Set(entries.slice(Math.floor(entries.length / 2)));
              }
              this.observedMessages.add(fp);
              this.messageBuffer.push(msg);
            }
          }
        } catch (err) {}
      }
    }

    /**
     * Analyze buffer — runs every 2s.
     * Drains messageBuffer, analyzes each message locally, discards after analysis.
     * If trigger returned, shows overlay with helplines.
     */
    analyzeBuffer() {
      if (this.messageBuffer.length === 0) return;

      const messages = this.messageBuffer.splice(0);

      for (const msg of messages) {
        const sender = msg.sender || SENDER_ROLES.USER;
        const result = this.analyzer.analyzeMessage(msg.content, sender);

        if (result) {
          console.log(`[Lighthouse] ${this.platformKey}: Trigger — ${result.categoryName} (score: ${result.score.toFixed(2)})`);
          this.overlay.show(result);
          // Stop analyzing remaining messages — overlay is showing
          break;
        }
      }
      // Messages are now discarded — never stored
    }

    destroy() {
      this.enabled = false;
      if (this.observerManager) this.observerManager.disconnect();
      if (this.analyzeInterval) clearInterval(this.analyzeInterval);
      if (this.containerCheckInterval) clearInterval(this.containerCheckInterval);
    }

    // --- Abstract methods ---

    getSelectors() {
      throw new Error('getSelectors() must be implemented');
    }

    extractMessagesFromNode(node) {
      throw new Error('extractMessagesFromNode() must be implemented');
    }

    getMessageFingerprint(msg) {
      return Utils.fingerprint(msg.sender, msg.content, msg.timestamp);
    }

    // --- Snooze support ---

    _loadSnoozeState() {
      try {
        const { browserAPI, MSG_TYPES } = window.Lighthouse;
        browserAPI.runtime.sendMessage({ type: MSG_TYPES.GET_SNOOZE_STATE }, (response) => {
          if (response && response.snoozedUntil) {
            this.analyzer.setSnoozedUntil(response.snoozedUntil);
          }
        });
      } catch (e) {
        // Service worker may not be ready yet
      }
    }
  }

  window.Lighthouse.BaseExtractor = BaseExtractor;
})();
