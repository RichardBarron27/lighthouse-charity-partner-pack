/**
 * Lighthouse by Red Specter — "Still Here"
 * ChatGPT Extractor
 * Monitors conversations on chat.openai.com and chatgpt.com
 */

(function () {
  const { BaseExtractor, SelectorEngine, SENDER_ROLES } = window.Lighthouse;

  class ChatGPTExtractor extends BaseExtractor {
    constructor() {
      super('chatgpt');
    }

    getSelectors() {
      return {
        messageContainer: [
          'main div.flex-1.overflow-hidden',
          'main div[class*="react-scroll-to-bottom"]',
          'main div[role="presentation"]',
          'main .overflow-y-auto',
          'main'
        ],
        messageRow: [
          'div[data-message-author-role]',
          'div[data-message-id]',
          'article[data-testid^="conversation-turn"]',
          'div.group\\/conversation-turn'
        ],
        messageText: [
          'div.markdown.prose',
          '.whitespace-pre-wrap',
          'div[class*="whitespace-pre"]',
          'div[data-message-id] .whitespace-pre-wrap',
          'div.text-message',
          '.markdown-body',
          'p'
        ],
        userMessage: [
          'div[data-message-author-role="user"]',
          'div[data-testid="conversation-turn-user"]'
        ],
        assistantMessage: [
          'div[data-message-author-role="assistant"]',
          'div[data-testid="conversation-turn-assistant"]'
        ]
      };
    }

    extractMessagesFromNode(node) {
      const messages = [];

      const authorRole = node.getAttribute?.('data-message-author-role');
      if (authorRole) {
        const msg = this._extractFromMessageDiv(node, authorRole);
        if (msg) messages.push(msg);
        return messages;
      }

      const messageDivs = SelectorEngine.queryAll(node, this.selectors.messageRow);
      for (const div of messageDivs) {
        const role = div.getAttribute?.('data-message-author-role');
        if (role) {
          const msg = this._extractFromMessageDiv(div, role);
          if (msg) messages.push(msg);
        } else {
          const msg = this._extractFromArticle(div);
          if (msg) messages.push(msg);
        }
      }

      return messages;
    }

    _extractFromMessageDiv(div, authorRole) {
      let content = SelectorEngine.getText(div, this.selectors.messageText);

      if (!content || content.length < 2) {
        content = (div.textContent || '').trim();
      }

      if (!content || content.length < 2) return null;

      const sender = authorRole === 'user'
        ? SENDER_ROLES.USER
        : SENDER_ROLES.AI;

      return {
        sender,
        content: content.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    _extractFromArticle(article) {
      const userDiv = SelectorEngine.queryFirst(article, this.selectors.userMessage);
      const assistantDiv = SelectorEngine.queryFirst(article, this.selectors.assistantMessage);

      let targetDiv = null;
      let sender = SENDER_ROLES.USER;

      if (userDiv) {
        targetDiv = userDiv;
        sender = SENDER_ROLES.USER;
      } else if (assistantDiv) {
        targetDiv = assistantDiv;
        sender = SENDER_ROLES.AI;
      } else {
        return null;
      }

      let content = SelectorEngine.getText(targetDiv, this.selectors.messageText);

      if (!content || content.length < 2) {
        content = (targetDiv.textContent || '').trim();
      }

      if (!content || content.length < 2) return null;

      return {
        sender,
        content: content.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    getMessageFingerprint(msg) {
      const truncated = (msg.content || '').substring(0, 80);
      return window.Lighthouse.Utils.hash(`${msg.sender}|${truncated}`);
    }
  }

  const extractor = new ChatGPTExtractor();
  extractor.init();
})();
