/**
 * Lighthouse by Red Specter — "Still Here"
 * Le Chat (Mistral) Extractor
 * Monitors conversations on chat.mistral.ai
 */

(function () {
  const { BaseExtractor, SENDER_ROLES } = window.Lighthouse;

  class LeChatExtractor extends BaseExtractor {
    constructor() {
      super('lechat');
    }

    async waitAndObserve() {
      const container = document.body;
      if (container) {
        console.log(`[Lighthouse] ${this.platformKey}: Using document.body as container`);
        this.observerManager = new window.Lighthouse.ObserverManager(this);
        this.observerManager.observe(container);
        this.currentContainer = container;
        this.extractExistingMessages(container);
      }
    }

    getSelectors() {
      return {
        messageContainer: ['body'],
        messageRow: ['[data-message-part-type="answer"]', '.select-none']
      };
    }

    _isAIMessage(el) {
      return el.getAttribute?.('data-message-part-type') === 'answer';
    }

    _isUserMessage(el) {
      if (!el.classList?.contains('select-none')) return false;
      return !!el.querySelector('span.whitespace-pre-wrap');
    }

    _getUserText(el) {
      const span = el.querySelector('span.whitespace-pre-wrap');
      return span ? (span.textContent || '').trim() : (el.textContent || '').trim();
    }

    _getAIText(el) {
      return (el.textContent || '').trim();
    }

    extractMessagesFromNode(node) {
      const messages = [];
      const processedTexts = new Set();

      if (this._isAIMessage(node)) {
        const msg = this._extractAI(node, processedTexts);
        if (msg) messages.push(msg);
        return messages;
      }
      if (this._isUserMessage(node)) {
        const msg = this._extractUser(node, processedTexts);
        if (msg) messages.push(msg);
        return messages;
      }

      const aiEls = node.querySelectorAll?.('[data-message-part-type="answer"]') || [];
      for (const el of aiEls) {
        const msg = this._extractAI(el, processedTexts);
        if (msg) messages.push(msg);
      }

      const userEls = node.querySelectorAll?.('.select-none') || [];
      for (const el of userEls) {
        if (!this._isUserMessage(el)) continue;
        if (el.closest('[data-message-part-type="answer"]')) continue;
        const msg = this._extractUser(el, processedTexts);
        if (msg) messages.push(msg);
      }

      if (messages.length === 0 && node.parentElement) {
        let parent = node.parentElement;
        for (let i = 0; i < 10 && parent; i++) {
          if (this._isAIMessage(parent)) {
            const msg = this._extractAI(parent, processedTexts);
            if (msg) messages.push(msg);
            break;
          }
          if (this._isUserMessage(parent)) {
            const msg = this._extractUser(parent, processedTexts);
            if (msg) messages.push(msg);
            break;
          }
          parent = parent.parentElement;
        }
      }

      return messages;
    }

    _extractUser(el, processedTexts) {
      const text = this._getUserText(el);
      if (text.length < 2) return null;

      const key = `USER:${text.substring(0, 80)}`;
      if (processedTexts.has(key)) return null;
      processedTexts.add(key);

      return {
        sender: SENDER_ROLES.USER,
        content: text.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    _extractAI(el, processedTexts) {
      const text = this._getAIText(el);
      if (text.length < 2) return null;

      const key = `AI:${text.substring(0, 80)}`;
      if (processedTexts.has(key)) return null;
      processedTexts.add(key);

      return {
        sender: SENDER_ROLES.AI,
        content: text.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    getMessageFingerprint(msg) {
      const truncated = (msg.content || '').substring(0, 80);
      return window.Lighthouse.Utils.hash(`${msg.sender}|${truncated}`);
    }
  }

  const extractor = new LeChatExtractor();
  extractor.init();
})();
