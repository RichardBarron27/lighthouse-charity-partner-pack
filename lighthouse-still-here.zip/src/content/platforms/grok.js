/**
 * Lighthouse by Red Specter — "Still Here"
 * Grok Extractor
 * Monitors conversations on grok.com
 */

(function () {
  const { BaseExtractor, SENDER_ROLES } = window.Lighthouse;

  class GrokExtractor extends BaseExtractor {
    constructor() {
      super('grok');
    }

    async waitAndObserve() {
      const container = document.body;
      if (container) {
        console.log(`[Lighthouse] ${this.platformKey}: Using document.body as container`);
        this.observerManager = new window.Lighthouse.ObserverManager(this);
        this.observerManager.observe(container);
        this.currentContainer = container;
        this.extractExistingMessages(container);
      }
    }

    getSelectors() {
      return {
        messageContainer: ['body'],
        messageRow: ['.message']
      };
    }

    _getMessageText(el) {
      const contentCol = el.querySelector('span.flex.dir-col');
      if (contentCol) {
        return (contentCol.textContent || '').trim();
      }
      return (el.textContent || '').trim();
    }

    _isUserMessage(el) {
      const container = el.closest('.m-container');
      if (container) {
        if (container.classList.contains('user')) return true;
        if (container.classList.contains('ai')) return false;
      }
      return true;
    }

    extractMessagesFromNode(node) {
      const messages = [];
      const processedTexts = new Set();
      const className = (typeof node.className === 'string' ? node.className : '');

      if (className.includes('message')) {
        const msg = this._extractFromMessageEl(node, processedTexts);
        if (msg) messages.push(msg);
        return messages;
      }

      const msgEls = node.querySelectorAll?.('.message') || [];
      for (const el of msgEls) {
        const msg = this._extractFromMessageEl(el, processedTexts);
        if (msg) messages.push(msg);
      }

      if (messages.length === 0 && node.parentElement) {
        let parent = node.parentElement;
        for (let i = 0; i < 10 && parent; i++) {
          const pcn = (typeof parent.className === 'string' ? parent.className : '');
          if (pcn.includes('message')) {
            const msg = this._extractFromMessageEl(parent, processedTexts);
            if (msg) messages.push(msg);
            break;
          }
          parent = parent.parentElement;
        }
      }

      return messages;
    }

    _extractFromMessageEl(el, processedTexts) {
      const text = this._getMessageText(el);
      if (text.length < 2) return null;

      const isUser = this._isUserMessage(el);
      const sender = isUser ? SENDER_ROLES.USER : SENDER_ROLES.AI;
      const senderLabel = isUser ? 'USER' : 'AI';

      const key = `${senderLabel}:${text.substring(0, 80)}`;
      if (processedTexts.has(key)) return null;
      processedTexts.add(key);

      return {
        sender,
        content: text.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    getMessageFingerprint(msg) {
      const truncated = (msg.content || '').substring(0, 80);
      return window.Lighthouse.Utils.hash(`${msg.sender}|${truncated}`);
    }
  }

  const extractor = new GrokExtractor();
  extractor.init();
})();
