/**
 * Lighthouse by Red Specter — "Still Here"
 * HuggingChat Extractor
 * Monitors conversations on huggingface.co/chat
 */

(function () {
  const { BaseExtractor, SENDER_ROLES } = window.Lighthouse;

  class HuggingChatExtractor extends BaseExtractor {
    constructor() {
      super('huggingchat');
    }

    async waitAndObserve() {
      const container = document.body;
      if (container) {
        console.log(`[Lighthouse] ${this.platformKey}: Using document.body as container`);
        this.observerManager = new window.Lighthouse.ObserverManager(this);
        this.observerManager.observe(container);
        this.currentContainer = container;
        this.extractExistingMessages(container);
      }
    }

    getSelectors() {
      return {
        messageContainer: ['body'],
        messageRow: ['p.disabled', 'div.prose']
      };
    }

    _isUserMessage(el) {
      return el.tagName === 'P' && el.classList.contains('disabled');
    }

    _isAIMessage(el) {
      return el.tagName === 'DIV' && el.classList.contains('prose');
    }

    extractMessagesFromNode(node) {
      const messages = [];
      const processedTexts = new Set();

      if (this._isUserMessage(node)) {
        const msg = this._extractUser(node, processedTexts);
        if (msg) messages.push(msg);
        return messages;
      }
      if (this._isAIMessage(node)) {
        const msg = this._extractAI(node, processedTexts);
        if (msg) messages.push(msg);
        return messages;
      }

      const userEls = node.querySelectorAll?.('p.disabled') || [];
      for (const el of userEls) {
        if (el.closest('.prose')) continue;
        const msg = this._extractUser(el, processedTexts);
        if (msg) messages.push(msg);
      }

      const aiEls = node.querySelectorAll?.('div.prose') || [];
      for (const el of aiEls) {
        const msg = this._extractAI(el, processedTexts);
        if (msg) messages.push(msg);
      }

      if (messages.length === 0 && node.parentElement) {
        let parent = node.parentElement;
        for (let i = 0; i < 10 && parent; i++) {
          if (this._isUserMessage(parent)) {
            const msg = this._extractUser(parent, processedTexts);
            if (msg) messages.push(msg);
            break;
          }
          if (this._isAIMessage(parent)) {
            const msg = this._extractAI(parent, processedTexts);
            if (msg) messages.push(msg);
            break;
          }
          parent = parent.parentElement;
        }
      }

      return messages;
    }

    _extractUser(el, processedTexts) {
      const text = (el.textContent || '').trim();
      if (text.length < 2) return null;

      const key = `USER:${text.substring(0, 80)}`;
      if (processedTexts.has(key)) return null;
      processedTexts.add(key);

      return {
        sender: SENDER_ROLES.USER,
        content: text.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    _extractAI(el, processedTexts) {
      const text = (el.textContent || '').trim();
      if (text.length < 2) return null;

      const key = `AI:${text.substring(0, 80)}`;
      if (processedTexts.has(key)) return null;
      processedTexts.add(key);

      return {
        sender: SENDER_ROLES.AI,
        content: text.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    getMessageFingerprint(msg) {
      const truncated = (msg.content || '').substring(0, 80);
      return window.Lighthouse.Utils.hash(`${msg.sender}|${truncated}`);
    }
  }

  const extractor = new HuggingChatExtractor();
  extractor.init();
})();
