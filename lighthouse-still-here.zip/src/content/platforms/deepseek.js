/**
 * Lighthouse by Red Specter — "Still Here"
 * DeepSeek Extractor
 * Monitors conversations on chat.deepseek.com
 */

(function () {
  const { BaseExtractor, SENDER_ROLES } = window.Lighthouse;

  class DeepSeekExtractor extends BaseExtractor {
    constructor() {
      super('deepseek');
    }

    async waitAndObserve() {
      const container = document.body;
      if (container) {
        console.log(`[Lighthouse] ${this.platformKey}: Using document.body as container`);
        this.observerManager = new window.Lighthouse.ObserverManager(this);
        this.observerManager.observe(container);
        this.currentContainer = container;
        this.extractExistingMessages(container);
      }
    }

    getSelectors() {
      return {
        messageContainer: ['body'],
        messageRow: ['.ds-message', '.ds-markdown']
      };
    }

    _getUserTextFromMessage(el) {
      const clone = el.cloneNode(true);
      const markdownEls = clone.querySelectorAll('.ds-markdown');
      for (const md of markdownEls) {
        md.remove();
      }
      return (clone.textContent || '').trim();
    }

    extractMessagesFromNode(node) {
      const messages = [];
      const processedTexts = new Set();

      const className = (typeof node.className === 'string' ? node.className : '');
      if (className.includes('ds-markdown')) {
        const msg = this._extractAI(node, processedTexts);
        if (msg) messages.push(msg);
        return messages;
      }

      if (className.includes('ds-message')) {
        const msg = this._extractUser(node, processedTexts);
        if (msg) messages.push(msg);
        const aiMsg = this._extractNestedAI(node, processedTexts);
        if (aiMsg) messages.push(aiMsg);
        return messages;
      }

      const msgEls = node.querySelectorAll?.('.ds-message') || [];
      for (const el of msgEls) {
        const userMsg = this._extractUser(el, processedTexts);
        if (userMsg) messages.push(userMsg);
        const aiMsg = this._extractNestedAI(el, processedTexts);
        if (aiMsg) messages.push(aiMsg);
      }

      const mdEls = node.querySelectorAll?.('.ds-markdown') || [];
      for (const el of mdEls) {
        if (el.closest('.ds-message')) continue;
        const msg = this._extractAI(el, processedTexts);
        if (msg) messages.push(msg);
      }

      if (messages.length === 0 && node.parentElement) {
        let parent = node.parentElement;
        for (let i = 0; i < 10 && parent; i++) {
          const pcn = (typeof parent.className === 'string' ? parent.className : '');
          if (pcn.includes('ds-markdown')) {
            const msg = this._extractAI(parent, processedTexts);
            if (msg) messages.push(msg);
            break;
          }
          if (pcn.includes('ds-message')) {
            const msg = this._extractUser(parent, processedTexts);
            if (msg) messages.push(msg);
            break;
          }
          parent = parent.parentElement;
        }
      }

      return messages;
    }

    _extractUser(el, processedTexts) {
      const text = this._getUserTextFromMessage(el);
      if (text.length < 2) return null;
      const key = 'user:' + text.substring(0, 80);
      if (processedTexts.has(key)) return null;
      processedTexts.add(key);
      return {
        sender: SENDER_ROLES.USER,
        content: text.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    _extractAI(el, processedTexts) {
      const text = (el.textContent || '').trim();
      if (text.length < 2) return null;
      const key = 'ai:' + text.substring(0, 80);
      if (processedTexts.has(key)) return null;
      processedTexts.add(key);
      return {
        sender: SENDER_ROLES.AI,
        content: text.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    _extractNestedAI(dsMessageEl, processedTexts) {
      const mdEl = dsMessageEl.querySelector('.ds-markdown');
      if (!mdEl) return null;
      return this._extractAI(mdEl, processedTexts);
    }

    getMessageFingerprint(msg) {
      const truncated = (msg.content || '').substring(0, 80);
      return window.Lighthouse.Utils.hash(`${msg.sender}|${truncated}`);
    }
  }

  const extractor = new DeepSeekExtractor();
  extractor.init();
})();
