/**
 * Lighthouse by Red Specter — "Still Here"
 * Perplexity Extractor
 * Monitors conversations on perplexity.ai
 */

(function () {
  const { BaseExtractor, SENDER_ROLES } = window.Lighthouse;

  class PerplexityExtractor extends BaseExtractor {
    constructor() {
      super('perplexity');
    }

    getSelectors() {
      return {
        messageContainer: [
          '[role="main"]',
          'main',
          '.max-w-threadContentWidth',
          '[class*="threadContentWidth"]'
        ],
        messageRow: [
          'span.select-text',
          '.prose'
        ],
        messageText: [
          'span.select-text',
          '.prose p',
          'p'
        ]
      };
    }

    extractMessagesFromNode(node) {
      const messages = [];
      const processedTexts = new Set();

      const directMsg = this._tryExtractDirect(node, processedTexts);
      if (directMsg) {
        messages.push(directMsg);
        return messages;
      }

      this._findUserQueries(node, messages, processedTexts);
      this._findAIAnswers(node, messages, processedTexts);

      if (messages.length === 0 && node.parentElement) {
        let parent = node.parentElement;
        for (let i = 0; i < 10 && parent; i++) {
          const parentMsg = this._tryExtractDirect(parent, processedTexts);
          if (parentMsg) {
            messages.push(parentMsg);
            break;
          }
          if (messages.length === 0) {
            this._findUserQueries(parent, messages, processedTexts);
            this._findAIAnswers(parent, messages, processedTexts);
            if (messages.length > 0) break;
          }
          parent = parent.parentElement;
        }
      }

      return messages;
    }

    _tryExtractDirect(node, processedTexts) {
      const tagName = (node.tagName || '').toLowerCase();
      const className = (typeof node.className === 'string' ? node.className : '');

      if (tagName === 'span' && className.includes('select-text')) {
        const text = (node.textContent || '').trim();
        if (text.length >= 2 && !processedTexts.has(text.substring(0, 80))) {
          processedTexts.add(text.substring(0, 80));
          return {
            sender: SENDER_ROLES.USER,
            content: text.substring(0, 2000),
            timestamp: new Date().toISOString()
          };
        }
      }

      if (tagName === 'div' && className.includes('bg-offset')) {
        const span = node.querySelector('span.select-text');
        if (span) {
          const text = (span.textContent || '').trim();
          if (text.length >= 2 && !processedTexts.has(text.substring(0, 80))) {
            processedTexts.add(text.substring(0, 80));
            return {
              sender: SENDER_ROLES.USER,
              content: text.substring(0, 2000),
              timestamp: new Date().toISOString()
            };
          }
        }
      }

      if (tagName === 'h1') {
        const span = node.querySelector('span.select-text');
        if (span) {
          const text = (span.textContent || '').trim();
          if (text.length >= 2 && !processedTexts.has(text.substring(0, 80))) {
            processedTexts.add(text.substring(0, 80));
            return {
              sender: SENDER_ROLES.USER,
              content: text.substring(0, 2000),
              timestamp: new Date().toISOString()
            };
          }
        }
      }

      if (tagName === 'div' && className.includes('prose')) {
        const text = (node.textContent || '').trim();
        if (text.length >= 2 && !processedTexts.has(text.substring(0, 80))) {
          processedTexts.add(text.substring(0, 80));
          return {
            sender: SENDER_ROLES.AI,
            content: text.substring(0, 2000),
            timestamp: new Date().toISOString()
          };
        }
      }

      return null;
    }

    _findUserQueries(node, messages, processedTexts) {
      const spans = node.querySelectorAll?.('span.select-text') || [];
      for (const span of spans) {
        const text = (span.textContent || '').trim();
        if (text.length >= 2 && !processedTexts.has(text.substring(0, 80))) {
          processedTexts.add(text.substring(0, 80));
          messages.push({
            sender: SENDER_ROLES.USER,
            content: text.substring(0, 2000),
            timestamp: new Date().toISOString()
          });
        }
      }
    }

    _findAIAnswers(node, messages, processedTexts) {
      const proseEls = node.querySelectorAll?.('div.prose') || [];
      for (const prose of proseEls) {
        const text = (prose.textContent || '').trim();
        if (text.length >= 2 && !processedTexts.has(text.substring(0, 80))) {
          processedTexts.add(text.substring(0, 80));
          messages.push({
            sender: SENDER_ROLES.AI,
            content: text.substring(0, 2000),
            timestamp: new Date().toISOString()
          });
        }
      }

      const className = (typeof node.className === 'string' ? node.className : '');
      if (className.includes('prose')) {
        const text = (node.textContent || '').trim();
        if (text.length >= 2 && !processedTexts.has(text.substring(0, 80))) {
          processedTexts.add(text.substring(0, 80));
          messages.push({
            sender: SENDER_ROLES.AI,
            content: text.substring(0, 2000),
            timestamp: new Date().toISOString()
          });
        }
      }
    }

    getMessageFingerprint(msg) {
      const truncated = (msg.content || '').substring(0, 80);
      return window.Lighthouse.Utils.hash(`${msg.sender}|${truncated}`);
    }
  }

  const extractor = new PerplexityExtractor();
  extractor.init();
})();
