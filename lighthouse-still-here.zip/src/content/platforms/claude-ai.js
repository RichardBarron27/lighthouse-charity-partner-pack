/**
 * Lighthouse by Red Specter — "Still Here"
 * Claude AI Extractor
 * Monitors conversations on claude.ai
 */

(function () {
  const { BaseExtractor, SENDER_ROLES } = window.Lighthouse;

  class ClaudeExtractor extends BaseExtractor {
    constructor() {
      super('claude');
      this._scanInterval = null;
    }

    async waitAndObserve() {
      const container = document.body;
      if (container) {
        console.log(`[Lighthouse] ${this.platformKey}: Using document.body as container`);
        this.observerManager = new window.Lighthouse.ObserverManager(this);
        this.observerManager.observe(container);
        this.currentContainer = container;
        this.extractExistingMessages(container);

        this._scanInterval = setInterval(() => this._periodicScan(), 3000);
      }
    }

    _periodicScan() {
      if (!this.enabled) return;

      const userEls = document.querySelectorAll('div[data-testid="user-message"]');
      for (const el of userEls) {
        const text = (el.textContent || '').trim();
        if (text.length < 2) continue;
        const fp = this.getMessageFingerprint({ sender: SENDER_ROLES.USER, content: text });
        if (!this.observedMessages.has(fp)) {
          this.observedMessages.add(fp);
          this.messageBuffer.push({
            sender: SENDER_ROLES.USER,
            content: text.substring(0, 2000),
            timestamp: new Date().toISOString()
          });
        }
      }

      const aiSelectors = [
        'div[data-testid="assistant-message"]',
        'div[data-testid="chat-message-assistant"]',
        'div[class*="font-claude-message"]',
        'div[class*="font-claude-response"]',
        'div[data-is-streaming]'
      ];

      for (const selector of aiSelectors) {
        try {
          const aiEls = document.querySelectorAll(selector);
          for (const el of aiEls) {
            if (this._isUserMessage(el)) continue;
            const text = (el.textContent || '').trim();
            if (text.length < 2) continue;
            const fp = this.getMessageFingerprint({ sender: SENDER_ROLES.AI, content: text });
            if (!this.observedMessages.has(fp)) {
              this.observedMessages.add(fp);
              this.messageBuffer.push({
                sender: SENDER_ROLES.AI,
                content: text.substring(0, 2000),
                timestamp: new Date().toISOString()
              });
            }
          }
        } catch (e) {}
      }
    }

    getSelectors() {
      return {
        messageContainer: ['body'],
        messageRow: [
          'div[data-testid="user-message"]',
          'div[data-testid="assistant-message"]',
          'div[data-testid="chat-message-user"]',
          'div[data-testid="chat-message-assistant"]',
          'div[class*="font-claude-message"]',
          'div[class*="font-claude-response"]',
          'div[data-is-streaming]'
        ]
      };
    }

    extractMessagesFromNode(node) {
      const messages = [];
      const processedTexts = new Set();

      if (this._isUserMessage(node)) {
        const msg = this._extractUser(node, processedTexts);
        if (msg) messages.push(msg);
        return messages;
      }

      if (this._isAIMessage(node)) {
        const msg = this._extractAI(node, processedTexts);
        if (msg) messages.push(msg);
        return messages;
      }

      const userEls = node.querySelectorAll?.('div[data-testid="user-message"]') || [];
      for (const el of userEls) {
        const msg = this._extractUser(el, processedTexts);
        if (msg) messages.push(msg);
      }

      const aiSelectors = [
        'div[data-testid="assistant-message"]',
        'div[data-testid="chat-message-assistant"]',
        'div[class*="font-claude-message"]',
        'div[class*="font-claude-response"]',
        'div[data-is-streaming]'
      ];

      for (const selector of aiSelectors) {
        try {
          const aiEls = node.querySelectorAll?.(selector) || [];
          for (const el of aiEls) {
            if (this._isUserMessage(el)) continue;
            const msg = this._extractAI(el, processedTexts);
            if (msg) messages.push(msg);
          }
        } catch (e) {}
      }

      if (messages.length === 0 && node.parentElement) {
        let parent = node.parentElement;
        for (let i = 0; i < 10 && parent; i++) {
          if (this._isUserMessage(parent)) {
            const msg = this._extractUser(parent, processedTexts);
            if (msg) messages.push(msg);
            break;
          }
          if (this._isAIMessage(parent)) {
            const msg = this._extractAI(parent, processedTexts);
            if (msg) messages.push(msg);
            break;
          }
          parent = parent.parentElement;
        }
      }

      return messages;
    }

    _isUserMessage(node) {
      if (!node || !node.getAttribute) return false;
      if (node.getAttribute('data-testid') === 'user-message') return true;
      if (node.getAttribute('data-testid') === 'chat-message-user') return true;
      const cn = typeof node.className === 'string' ? node.className : '';
      if (cn.includes('font-user-message')) return true;
      return false;
    }

    _isAIMessage(node) {
      if (!node || !node.getAttribute) return false;
      if (node.getAttribute('data-testid') === 'assistant-message') return true;
      if (node.getAttribute('data-testid') === 'chat-message-assistant') return true;
      if (node.hasAttribute?.('data-is-streaming')) return true;
      const cn = typeof node.className === 'string' ? node.className : '';
      if (cn.includes('font-claude-message')) return true;
      if (cn.includes('font-claude-response')) return true;
      return false;
    }

    _extractUser(el, processedTexts) {
      const text = (el.textContent || '').trim();
      if (text.length < 2) return null;
      const key = 'user:' + text.substring(0, 80);
      if (processedTexts.has(key)) return null;
      processedTexts.add(key);
      return {
        sender: SENDER_ROLES.USER,
        content: text.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    _extractAI(el, processedTexts) {
      const text = (el.textContent || '').trim();
      if (text.length < 2) return null;
      const key = 'ai:' + text.substring(0, 80);
      if (processedTexts.has(key)) return null;
      processedTexts.add(key);
      return {
        sender: SENDER_ROLES.AI,
        content: text.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    getMessageFingerprint(msg) {
      const truncated = (msg.content || '').substring(0, 80);
      return window.Lighthouse.Utils.hash(`${msg.sender}|${truncated}`);
    }

    destroy() {
      if (this._scanInterval) clearInterval(this._scanInterval);
      super.destroy();
    }
  }

  const extractor = new ClaudeExtractor();
  extractor.init();
})();
