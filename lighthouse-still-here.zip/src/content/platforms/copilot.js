/**
 * Lighthouse by Red Specter — "Still Here"
 * Microsoft Copilot Extractor
 * Monitors conversations on copilot.microsoft.com
 */

(function () {
  const { BaseExtractor, SelectorEngine, SENDER_ROLES } = window.Lighthouse;

  class CopilotExtractor extends BaseExtractor {
    constructor() {
      super('copilot');
    }

    getSelectors() {
      return {
        messageContainer: [
          '[class*="conversation"]',
          '[role="main"]',
          'main',
          '[class*="chat-container"]'
        ],
        messageRow: [
          '[data-content="user-message"], [data-content="ai-message"]',
          '[data-content="user-message"]',
          '[data-content="ai-message"]'
        ],
        messageText: [
          'p',
          '.whitespace-pre-wrap',
          'span',
          'div'
        ]
      };
    }

    extractMessagesFromNode(node) {
      const messages = [];

      const dataContent = node.getAttribute?.('data-content');
      if (dataContent === 'user-message' || dataContent === 'ai-message') {
        const msg = this._extractFromDiv(node, dataContent);
        if (msg) messages.push(msg);
        return messages;
      }

      const messageDivs = SelectorEngine.queryAll(node, this.selectors.messageRow);
      for (const div of messageDivs) {
        const dc = div.getAttribute?.('data-content');
        if (dc) {
          const msg = this._extractFromDiv(div, dc);
          if (msg) messages.push(msg);
        }
      }

      if (messages.length === 0 && node.parentElement) {
        let parent = node.parentElement;
        for (let i = 0; i < 5 && parent; i++) {
          const dc = parent.getAttribute?.('data-content');
          if (dc === 'user-message' || dc === 'ai-message') {
            const msg = this._extractFromDiv(parent, dc);
            if (msg) messages.push(msg);
            break;
          }
          parent = parent.parentElement;
        }
      }

      return messages;
    }

    _extractFromDiv(div, dataContent) {
      let content = SelectorEngine.getText(div, this.selectors.messageText);

      if (!content || content.length < 2) {
        content = (div.textContent || '').trim();
      }

      if (!content || content.length < 2) return null;

      const sender = dataContent === 'user-message'
        ? SENDER_ROLES.USER
        : SENDER_ROLES.AI;

      return {
        sender,
        content: content.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    getMessageFingerprint(msg) {
      const truncated = (msg.content || '').substring(0, 80);
      return window.Lighthouse.Utils.hash(`${msg.sender}|${truncated}`);
    }
  }

  const extractor = new CopilotExtractor();
  extractor.init();
})();
