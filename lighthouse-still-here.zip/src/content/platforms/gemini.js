/**
 * Lighthouse by Red Specter — "Still Here"
 * Google Gemini Extractor
 * Monitors conversations on gemini.google.com
 */

(function () {
  const { BaseExtractor, SelectorEngine, SENDER_ROLES } = window.Lighthouse;

  class GeminiExtractor extends BaseExtractor {
    constructor() {
      super('gemini');
    }

    getSelectors() {
      return {
        messageContainer: [
          'chat-window',
          '[class*="conversation-container"]',
          '[class*="chat-container"]',
          '[role="main"]',
          'main'
        ],
        messageRow: [
          'user-query, model-response',
          '[data-model-response]',
          '[class*="model-response"]'
        ],
        userTextSelectors: [
          'div.query-content',
          '.query-text',
          'p'
        ],
        assistantTextSelectors: [
          'message-content .markdown',
          'message-content',
          '.response-content',
          '[class*="response-container"]',
          '.markdown',
          'p'
        ]
      };
    }

    extractMessagesFromNode(node) {
      const messages = [];
      const tagName = (node.tagName || '').toLowerCase();

      if (tagName === 'user-query' || tagName === 'model-response') {
        const msg = this._extractFromElement(node, tagName);
        if (msg) messages.push(msg);
        return messages;
      }

      const messageEls = SelectorEngine.queryAll(node, this.selectors.messageRow);
      for (const el of messageEls) {
        const elTag = (el.tagName || '').toLowerCase();
        const msg = this._extractFromElement(el, elTag);
        if (msg) messages.push(msg);
      }

      if (messages.length === 0 && node.parentElement) {
        let parent = node.parentElement;
        for (let i = 0; i < 5 && parent; i++) {
          const pTag = (parent.tagName || '').toLowerCase();
          if (pTag === 'user-query' || pTag === 'model-response') {
            const msg = this._extractFromElement(parent, pTag);
            if (msg) messages.push(msg);
            break;
          }
          parent = parent.parentElement;
        }
      }

      return messages;
    }

    _extractFromElement(el, tagName) {
      const isUser = tagName === 'user-query';
      const isAssistant = tagName === 'model-response' || el.hasAttribute?.('data-model-response');

      if (!isUser && !isAssistant) {
        if (el.matches?.('[data-model-response], [class*="model-response"]')) {
          return this._getContent(el, false);
        }
        return null;
      }

      return this._getContent(el, isUser);
    }

    _getContent(el, isUser) {
      const selectors = isUser ? this.selectors.userTextSelectors : this.selectors.assistantTextSelectors;
      let content = SelectorEngine.getText(el, selectors);

      if (!content || content.length < 2) {
        content = (el.textContent || '').trim();
      }

      if (!content || content.length < 2) return null;

      if (isUser) {
        content = content.replace(/^You said\s*/i, '');
        if (!content || content.length < 2) return null;
      }

      return {
        sender: isUser ? SENDER_ROLES.USER : SENDER_ROLES.AI,
        content: content.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    getMessageFingerprint(msg) {
      const truncated = (msg.content || '').substring(0, 80);
      return window.Lighthouse.Utils.hash(`${msg.sender}|${truncated}`);
    }
  }

  const extractor = new GeminiExtractor();
  extractor.init();
})();
