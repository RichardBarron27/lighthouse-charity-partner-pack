/**
 * Lighthouse by Red Specter — "Still Here"
 * Character.ai Extractor
 * Monitors conversations on character.ai
 */

(function () {
  const { BaseExtractor, SelectorEngine, SENDER_ROLES } = window.Lighthouse;

  class CharacterAIExtractor extends BaseExtractor {
    constructor() {
      super('character_ai');
    }

    getSelectors() {
      return {
        messageContainer: [
          '[role="main"]',
          'main',
          '[class*="swiper"]',
          'body'
        ],
        messageRow: [
          '[data-testid="completed-message"]',
          '.swiper-no-swiping'
        ],
        messageText: [
          '.prose p',
          '.prose',
          'p',
          'span'
        ]
      };
    }

    extractMessagesFromNode(node) {
      const messages = [];

      if (this._isMessageNode(node)) {
        const msg = this._extractFromNode(node);
        if (msg) messages.push(msg);
        return messages;
      }

      const messageDivs = node.querySelectorAll?.('[data-testid="completed-message"]') || [];
      for (const div of messageDivs) {
        const msg = this._extractFromNode(div);
        if (msg) messages.push(msg);
      }

      if (messageDivs.length === 0) {
        const swiperDivs = node.querySelectorAll?.('.swiper-no-swiping') || [];
        for (const div of swiperDivs) {
          const msg = this._extractFromNode(div);
          if (msg) messages.push(msg);
        }
      }

      if (messages.length === 0 && node.parentElement) {
        let parent = node.parentElement;
        for (let i = 0; i < 8 && parent; i++) {
          if (this._isMessageNode(parent)) {
            const msg = this._extractFromNode(parent);
            if (msg) messages.push(msg);
            break;
          }
          parent = parent.parentElement;
        }
      }

      return messages;
    }

    _isMessageNode(node) {
      const testId = node.getAttribute?.('data-testid') || '';
      if (testId === 'completed-message') return true;
      const className = (typeof node.className === 'string' ? node.className : '');
      if (className.includes('swiper-no-swiping')) return true;
      return false;
    }

    _extractFromNode(node) {
      const proseEl = node.querySelector?.('.prose');
      let content = '';

      if (proseEl) {
        const paragraphs = proseEl.querySelectorAll('p');
        if (paragraphs.length > 0) {
          content = Array.from(paragraphs).map(p => p.textContent).join('\n').trim();
        } else {
          content = proseEl.textContent?.trim() || '';
        }
      }

      if (!content || content.length < 2) {
        content = SelectorEngine.getText(node, this.selectors.messageText);
      }

      if (!content || content.length < 2) {
        content = (node.textContent || '').trim();
      }

      if (!content || content.length < 2) return null;

      const sender = this._detectSender(node);

      return {
        sender,
        content: content.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    _detectSender(node) {
      let el = node;
      for (let i = 0; i < 10 && el; i++) {
        const className = (typeof el.className === 'string' ? el.className : '');

        if (className.includes('flex-row-reverse')) {
          return SENDER_ROLES.USER;
        }

        if (className.includes('items-end') && className.includes('flex-col')) {
          return SENDER_ROLES.USER;
        }

        if (className.includes('items-start') && className.includes('flex') && className.includes('gap-2') && !className.includes('flex-row-reverse')) {
          return SENDER_ROLES.AI;
        }

        el = el.parentElement;
      }

      return SENDER_ROLES.AI;
    }

    getMessageFingerprint(msg) {
      const truncated = (msg.content || '').substring(0, 80);
      return window.Lighthouse.Utils.hash(`${msg.sender}|${truncated}`);
    }
  }

  const extractor = new CharacterAIExtractor();
  extractor.init();
})();
