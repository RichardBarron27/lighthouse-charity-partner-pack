/**
 * Lighthouse by Red Specter — "Still Here"
 * Pi Extractor
 * Monitors conversations on pi.ai
 */

(function () {
  const { BaseExtractor, SENDER_ROLES } = window.Lighthouse;

  class PiExtractor extends BaseExtractor {
    constructor() {
      super('pi');
    }

    async waitAndObserve() {
      const container = document.body;
      if (container) {
        console.log(`[Lighthouse] ${this.platformKey}: Using document.body as container`);
        this.observerManager = new window.Lighthouse.ObserverManager(this);
        this.observerManager.observe(container);
        this.currentContainer = container;
        this.extractExistingMessages(container);
      }
    }

    getSelectors() {
      return {
        messageContainer: ['body'],
        messageRow: ['.ml-auto.bg-neutral-200', '.whitespace-pre-wrap.mb-4']
      };
    }

    _isUserMessage(el) {
      return el.classList.contains('ml-auto') && el.classList.contains('bg-neutral-200');
    }

    _isAIMessage(el) {
      return el.classList.contains('whitespace-pre-wrap');
    }

    extractMessagesFromNode(node) {
      const messages = [];
      const processedTexts = new Set();

      if (this._isUserMessage(node)) {
        const msg = this._extractMessage(node, SENDER_ROLES.USER, processedTexts);
        if (msg) messages.push(msg);
        return messages;
      }
      if (this._isAIMessage(node)) {
        const msg = this._extractMessage(node, SENDER_ROLES.AI, processedTexts);
        if (msg) messages.push(msg);
        return messages;
      }

      const userEls = node.querySelectorAll?.('.ml-auto.bg-neutral-200') || [];
      for (const el of userEls) {
        const msg = this._extractMessage(el, SENDER_ROLES.USER, processedTexts);
        if (msg) messages.push(msg);
      }

      const aiEls = node.querySelectorAll?.('.whitespace-pre-wrap') || [];
      for (const el of aiEls) {
        if (this._isUserMessage(el)) continue;
        const msg = this._extractMessage(el, SENDER_ROLES.AI, processedTexts);
        if (msg) messages.push(msg);
      }

      if (messages.length === 0 && node.parentElement) {
        let parent = node.parentElement;
        for (let i = 0; i < 10 && parent; i++) {
          if (this._isUserMessage(parent)) {
            const msg = this._extractMessage(parent, SENDER_ROLES.USER, processedTexts);
            if (msg) messages.push(msg);
            break;
          }
          if (this._isAIMessage(parent)) {
            const msg = this._extractMessage(parent, SENDER_ROLES.AI, processedTexts);
            if (msg) messages.push(msg);
            break;
          }
          parent = parent.parentElement;
        }
      }

      return messages;
    }

    _extractMessage(el, sender, processedTexts) {
      const text = (el.textContent || '').trim();
      if (text.length < 2) return null;

      const senderLabel = sender === SENDER_ROLES.USER ? 'USER' : 'AI';
      const key = `${senderLabel}:${text.substring(0, 80)}`;
      if (processedTexts.has(key)) return null;
      processedTexts.add(key);

      return {
        sender,
        content: text.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    getMessageFingerprint(msg) {
      const truncated = (msg.content || '').substring(0, 80);
      return window.Lighthouse.Utils.hash(`${msg.sender}|${truncated}`);
    }
  }

  const extractor = new PiExtractor();
  extractor.init();
})();
