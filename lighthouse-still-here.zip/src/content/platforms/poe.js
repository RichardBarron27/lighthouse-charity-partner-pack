/**
 * Lighthouse by Red Specter — "Still Here"
 * Poe Extractor
 * Monitors conversations on poe.com
 */

(function () {
  const { BaseExtractor, SelectorEngine, SENDER_ROLES } = window.Lighthouse;

  class PoeExtractor extends BaseExtractor {
    constructor() {
      super('poe');
    }

    getSelectors() {
      return {
        messageContainer: [
          '[class*="ChatMessagesView_infiniteScroll"]',
          '[class*="infiniteScroll"]',
          '[class*="chat-messages"]',
          '[role="main"]',
          'main'
        ],
        messageRow: [
          '[class*="ChatMessage_messageRow"]',
          '[class*="messageRow"]',
          '[class*="MessageBubble"]',
          '[class*="Message_"]'
        ],
        messageText: [
          '[class*="Markdown_markdownContainer"]',
          '[class*="markdownContainer"]',
          '[class*="Message_text"]',
          '.prose',
          'p'
        ],
        userIndicators: [
          '[class*="humanMessageBubble"]',
          '[class*="humanMessage"]',
          '[class*="rightSide"]'
        ],
        assistantIndicators: [
          '[class*="botMessageBubble"]',
          '[class*="botMessage"]',
          '[class*="leftSide"]'
        ]
      };
    }

    extractMessagesFromNode(node) {
      const messages = [];

      if (this._isMessageRow(node)) {
        const msg = this._extractFromRow(node);
        if (msg) messages.push(msg);
        return messages;
      }

      const rows = SelectorEngine.queryAll(node, this.selectors.messageRow);
      for (const row of rows) {
        const msg = this._extractFromRow(row);
        if (msg) messages.push(msg);
      }

      if (messages.length === 0 && node.parentElement) {
        let parent = node.parentElement;
        for (let i = 0; i < 5 && parent; i++) {
          if (this._isMessageRow(parent)) {
            const msg = this._extractFromRow(parent);
            if (msg) messages.push(msg);
            break;
          }
          parent = parent.parentElement;
        }
      }

      return messages;
    }

    _isMessageRow(node) {
      const className = (typeof node.className === 'string' ? node.className : '');
      return className.includes('messageRow') ||
             className.includes('MessageBubble') ||
             className.includes('Message_');
    }

    _extractFromRow(row) {
      let content = SelectorEngine.getText(row, this.selectors.messageText);

      if (!content || content.length < 2) {
        content = (row.textContent || '').trim();
      }

      if (!content || content.length < 2) return null;

      const sender = this._detectSender(row);

      return {
        sender,
        content: content.substring(0, 2000),
        timestamp: new Date().toISOString()
      };
    }

    _detectSender(node) {
      let el = node;
      for (let i = 0; i < 8 && el; i++) {
        const className = (typeof el.className === 'string' ? el.className : '');

        if (className.includes('humanMessageBubble') ||
            className.includes('humanMessage') ||
            className.includes('rightSide')) {
          return SENDER_ROLES.USER;
        }

        if (className.includes('botMessageBubble') ||
            className.includes('botMessage') ||
            className.includes('leftSide')) {
          return SENDER_ROLES.AI;
        }

        el = el.parentElement;
      }

      if (SelectorEngine.queryFirst(node, this.selectors.userIndicators)) {
        return SENDER_ROLES.USER;
      }
      if (SelectorEngine.queryFirst(node, this.selectors.assistantIndicators)) {
        return SENDER_ROLES.AI;
      }

      return SENDER_ROLES.AI;
    }

    getMessageFingerprint(msg) {
      const truncated = (msg.content || '').substring(0, 80);
      return window.Lighthouse.Utils.hash(`${msg.sender}|${truncated}`);
    }
  }

  const extractor = new PoeExtractor();
  extractor.init();
})();
