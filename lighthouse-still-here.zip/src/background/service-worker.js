/**
 * Lighthouse by Red Specter — "Still Here"
 * Service Worker (Background)
 *
 * Minimal — handles snooze state only.
 * No API calls, no queue, no alarms, no heartbeat.
 */

const SNOOZE_KEY = 'snoozeUntil';
const SNOOZE_DURATION_MS = 3600000; // 1 hour

chrome.runtime.onInstalled.addListener(() => {
  // Clear stale snooze on install/update
  chrome.storage.local.remove(SNOOZE_KEY);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_SNOOZE_STATE') {
    chrome.storage.local.get(SNOOZE_KEY, (result) => {
      const snoozedUntil = result[SNOOZE_KEY] || 0;
      const now = Date.now();
      if (snoozedUntil && now >= snoozedUntil) {
        // Snooze expired — clear it
        chrome.storage.local.remove(SNOOZE_KEY);
        sendResponse({ snoozedUntil: 0 });
      } else {
        sendResponse({ snoozedUntil });
      }
    });
    return true; // async response
  }

  if (message.type === 'SET_SNOOZE') {
    const until = Date.now() + SNOOZE_DURATION_MS;
    chrome.storage.local.set({ [SNOOZE_KEY]: until }, () => {
      sendResponse({ snoozedUntil: until });
    });
    return true;
  }

  if (message.type === 'CLEAR_SNOOZE') {
    chrome.storage.local.remove(SNOOZE_KEY, () => {
      sendResponse({ snoozedUntil: 0 });
    });
    return true;
  }

  if (message.type === 'GET_STATUS') {
    sendResponse({ status: 'active', version: chrome.runtime.getManifest().version });
    return false;
  }
});
