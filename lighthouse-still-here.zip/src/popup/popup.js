/**
 * Lighthouse by Red Specter — "Still Here"
 * Popup Script
 */

(function () {
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const snoozeBtn = document.getElementById('snoozeBtn');
  const versionText = document.getElementById('versionText');

  // Supported platform domains
  const SUPPORTED_DOMAINS = [
    'chat.openai.com', 'chatgpt.com',
    'claude.ai',
    'gemini.google.com',
    'copilot.microsoft.com',
    'character.ai',
    'chat.deepseek.com',
    'grok.com',
    'pi.ai',
    'poe.com',
    'perplexity.ai',
    'huggingface.co',
    'chat.mistral.ai'
  ];

  // Set version
  try {
    const manifest = chrome.runtime.getManifest();
    versionText.textContent = `v${manifest.version}`;
  } catch (e) {}

  // Check current tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]?.url) {
      setStatus('inactive', 'No active tab');
      return;
    }

    try {
      const url = new URL(tabs[0].url);
      const isSupported = SUPPORTED_DOMAINS.some(d => url.hostname === d || url.hostname.endsWith('.' + d));

      if (isSupported) {
        checkSnoozeAndSetStatus();
      } else {
        setStatus('inactive', 'Not a supported platform');
      }
    } catch (e) {
      setStatus('inactive', 'Not a supported platform');
    }
  });

  function checkSnoozeAndSetStatus() {
    chrome.runtime.sendMessage({ type: 'GET_SNOOZE_STATE' }, (response) => {
      if (chrome.runtime.lastError) {
        setStatus('active', 'Active');
        return;
      }

      if (response && response.snoozedUntil && Date.now() < response.snoozedUntil) {
        const until = new Date(response.snoozedUntil);
        const timeStr = until.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        setStatus('snoozed', `Snoozed until ${timeStr}`);
        snoozeBtn.textContent = 'Cancel snooze';
        snoozeBtn.classList.add('cancel');
      } else {
        setStatus('active', 'Active');
      }
    });
  }

  function setStatus(state, text) {
    statusDot.className = 'status-dot ' + state;
    statusText.textContent = text;
  }

  // Snooze button
  snoozeBtn.addEventListener('click', () => {
    if (snoozeBtn.classList.contains('cancel')) {
      chrome.runtime.sendMessage({ type: 'CLEAR_SNOOZE' }, () => {
        setStatus('active', 'Active');
        snoozeBtn.textContent = 'Snooze for 1 hour';
        snoozeBtn.classList.remove('cancel');
      });
    } else {
      chrome.runtime.sendMessage({ type: 'SET_SNOOZE' }, (response) => {
        if (response && response.snoozedUntil) {
          const until = new Date(response.snoozedUntil);
          const timeStr = until.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          setStatus('snoozed', `Snoozed until ${timeStr}`);
          snoozeBtn.textContent = 'Cancel snooze';
          snoozeBtn.classList.add('cancel');
        }
      });
    }
  });
})();
