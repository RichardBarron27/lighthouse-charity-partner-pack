# Lighthouse by Red Specter — "Still Here"

A free, open-source browser extension that silently monitors AI chatbot conversations and shows crisis helpline numbers when the conversation turns dark.

**No data collection. No servers. No accounts. Everything runs locally in your browser.**

## Who is it for?

Anyone who might be vulnerable during a conversation with an AI chatbot:

- Young people dealing with self-harm, eating disorders, or bullying
- Older adults experiencing loneliness and isolation
- Anyone going through depression, despair, or crisis

## What does it do?

Lighthouse watches the text in AI chatbot conversations — entirely on your device — and if it detects signs of distress, it gently slides in a panel with real helpline numbers. That's it. No judgement, no alerts to anyone else, no data stored.

## Supported platforms

| Platform | URL |
|---|---|
| ChatGPT | chat.openai.com / chatgpt.com |
| Claude | claude.ai |
| Google Gemini | gemini.google.com |
| Microsoft Copilot | copilot.microsoft.com |
| Character.ai | character.ai |
| DeepSeek | chat.deepseek.com |
| Grok | grok.com |
| Pi | pi.ai |
| Poe | poe.com |
| Perplexity | perplexity.ai |
| HuggingChat | huggingface.co/chat |
| Le Chat (Mistral) | chat.mistral.ai |

## Helplines (UK)

| Service | Contact | Hours |
|---|---|---|
| **Samaritans** | Call **116 123** | 24/7 |
| **Childline** | Call **0800 1111** | 24/7 |
| **YoungMinds** | Text **YM to 85258** | 24/7 |
| **The Silver Line** | Call **0800 4 70 80 90** | 24/7 |
| **Age UK** | Call **0800 678 1602** | 8am-7pm |
| **Mind** | Call **0300 123 3393** | Mon-Fri |
| **Crisis Text Line** | Text **HELLO to 85258** | 24/7 |
| **Beat Eating Disorders** | Call **0808 801 0677** | Weekdays + weekends |

The extension automatically picks the most relevant helplines based on conversation context (age indicators, risk category).

## Install

### Chrome

1. Download and unzip the extension
2. Open `chrome://extensions/`
3. Enable **Developer mode** (toggle in top-right)
4. Click **Load unpacked**
5. Select the `lighthouse-extension` folder (the one with `manifest.json`)

### Firefox

1. Download and unzip the extension
2. Open `about:debugging#/runtime/this-firefox`
3. Click **Load Temporary Add-on**
4. Select `manifest.firefox.json` from the `lighthouse-extension` folder

## Privacy

- **No data collection** — messages are analyzed in memory and immediately discarded
- **No network calls** — the extension makes zero outbound requests, ever
- **No accounts** — install and it works, nothing to sign up for
- **No storage of conversations** — only a snooze timestamp is saved locally
- **Open source** — read every line of code yourself

## How it works

1. Content scripts extract message text from the chatbot page DOM
2. A local pattern matching engine checks for ~103 crisis indicators across 4 categories
3. If the score exceeds the threshold, a Shadow DOM overlay slides in with helpline numbers
4. The overlay can be dismissed or snoozed for 1 hour
5. A 5-minute cooldown prevents alert fatigue
6. All messages are discarded after analysis — nothing is stored

## Build

```bash
chmod +x build.sh
./build.sh
```

Creates `dist/lighthouse-chrome.zip` and `dist/lighthouse-firefox.zip`.

## Licence

MIT — see [LICENSE](LICENSE)

## By

**Red Specter Security Research** — Innovation Beyond Belief

red-specter.co.uk
